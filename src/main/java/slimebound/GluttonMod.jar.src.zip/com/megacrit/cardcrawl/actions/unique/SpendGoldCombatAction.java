/*    */ package com.megacrit.cardcrawl.actions.unique;
/*    */ 
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.CardGroup;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.helpers.Hitbox;
/*    */ import com.megacrit.cardcrawl.vfx.GainPennyEffect;
/*    */ import gluttonmod.cards.AbstractGluttonCard;
/*    */ 
/*    */ public class SpendGoldCombatAction extends com.megacrit.cardcrawl.actions.AbstractGameAction
/*    */ {
/*    */   private int loseGold;
/*    */   private static final float DURATION = 0.1F;
/*    */   
/*    */   public SpendGoldCombatAction(int goldAmount)
/*    */   {
/* 18 */     this.loseGold = goldAmount;
/* 19 */     this.actionType = com.megacrit.cardcrawl.actions.AbstractGameAction.ActionType.DEBUFF;
/* 20 */     this.duration = 0.1F;
/*    */   }
/*    */   
/*    */   public void update() {
/*    */     AbstractPlayer p;
/* 25 */     if (this.duration == 0.1F)
/*    */     {
/* 27 */       p = AbstractDungeon.player;
/* 28 */       p.loseGold(this.loseGold);
/* 29 */       for (int i = 0; i < this.loseGold; i++) {
/* 30 */         AbstractDungeon.effectList.add(new GainPennyEffect(p, p.hb.cX, p.hb.cY, 0.0F, 0.0F, false));
/*    */       }
/*    */     }
/*    */     
/* 34 */     tickDuration();
/*    */     
/* 36 */     for (AbstractCard c : AbstractDungeon.player.hand.group) {
/* 37 */       if ((c instanceof AbstractGluttonCard)) {
/* 38 */         ((AbstractGluttonCard)c).onLoseGoldFromCard(this.loseGold);
/*    */       }
/*    */     }
/* 41 */     for (AbstractCard c : AbstractDungeon.player.drawPile.group) {
/* 42 */       if ((c instanceof AbstractGluttonCard)) {
/* 43 */         ((AbstractGluttonCard)c).onLoseGoldFromCard(this.loseGold);
/*    */       }
/*    */     }
/* 46 */     for (AbstractCard c : AbstractDungeon.player.discardPile.group) {
/* 47 */       if ((c instanceof AbstractGluttonCard)) {
/* 48 */         ((AbstractGluttonCard)c).onLoseGoldFromCard(this.loseGold);
/*    */       }
/*    */     }
/* 51 */     for (AbstractCard c : AbstractDungeon.player.exhaustPile.group) {
/* 52 */       if ((c instanceof AbstractGluttonCard)) {
/* 53 */         ((AbstractGluttonCard)c).onLoseGoldFromCard(this.loseGold);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\com\megacrit\cardcrawl\actions\unique\SpendGoldCombatAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */