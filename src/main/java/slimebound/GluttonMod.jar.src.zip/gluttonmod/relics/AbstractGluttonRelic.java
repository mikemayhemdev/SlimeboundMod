/*    */ package gluttonmod.relics;
/*    */ 
/*    */ import basemod.abstracts.CustomRelic;
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic.LandingSound;
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic.RelicTier;
/*    */ 
/*    */ public abstract class AbstractGluttonRelic extends CustomRelic
/*    */ {
/*    */   public AbstractGluttonRelic(String id, String img, AbstractRelic.RelicTier tier, AbstractRelic.LandingSound sfx)
/*    */   {
/* 11 */     super(id, new com.badlogic.gdx.graphics.Texture(gluttonmod.GluttonMod.getResourcePath(img)), tier, sfx);
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\relics\AbstractGluttonRelic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */