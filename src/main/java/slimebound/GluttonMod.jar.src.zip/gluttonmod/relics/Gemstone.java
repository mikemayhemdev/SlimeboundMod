/*    */ package gluttonmod.relics;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.ApplyPowerAction;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic.LandingSound;
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic.RelicTier;
/*    */ 
/*    */ public class Gemstone extends AbstractGluttonRelic
/*    */ {
/*    */   public static final String ID = "Gemstone";
/* 12 */   private static final AbstractRelic.RelicTier TIER = AbstractRelic.RelicTier.BOSS;
/*    */   private static final String IMG = "relics/gemstone.png";
/* 14 */   private static final AbstractRelic.LandingSound SOUND = AbstractRelic.LandingSound.CLINK;
/*    */   
/*    */   public Gemstone() {
/* 17 */     super("Gemstone", "relics/gemstone.png", TIER, SOUND);
/*    */   }
/*    */   
/*    */   public String getUpdatedDescription()
/*    */   {
/* 22 */     return this.DESCRIPTIONS[0];
/*    */   }
/*    */   
/*    */   public void atBattleStart()
/*    */   {
/* 27 */     if (AbstractDungeon.player.gold >= 300) {
/* 28 */       flash();
/* 29 */       AbstractDungeon.actionManager.addToTop(new ApplyPowerAction(AbstractDungeon.player, AbstractDungeon.player, new com.megacrit.cardcrawl.powers.StrengthPower(AbstractDungeon.player, 2), 2));
/*    */       
/*    */ 
/* 32 */       AbstractDungeon.actionManager.addToTop(new ApplyPowerAction(AbstractDungeon.player, AbstractDungeon.player, new com.megacrit.cardcrawl.powers.DexterityPower(AbstractDungeon.player, 2), 2));
/*    */       
/*    */ 
/*    */ 
/* 36 */       AbstractDungeon.actionManager.addToTop(new com.megacrit.cardcrawl.actions.common.RelicAboveCreatureAction(AbstractDungeon.player, this));
/*    */     }
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.relics.AbstractRelic makeCopy() {
/* 41 */     return new Gemstone();
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\relics\Gemstone.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */