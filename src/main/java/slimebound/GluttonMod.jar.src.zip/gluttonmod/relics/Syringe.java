/*    */ package gluttonmod.relics;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.RelicAboveCreatureAction;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic.LandingSound;
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic.RelicTier;
/*    */ import com.megacrit.cardcrawl.rooms.AbstractRoom;
/*    */ 
/*    */ public class Syringe extends AbstractGluttonRelic
/*    */ {
/*    */   public static final String ID = "Syringe";
/* 13 */   private static final AbstractRelic.RelicTier TIER = AbstractRelic.RelicTier.RARE;
/*    */   private static final String IMG = "relics/syringe.png";
/* 15 */   private static final AbstractRelic.LandingSound SOUND = AbstractRelic.LandingSound.CLINK;
/*    */   
/*    */   public Syringe() {
/* 18 */     super("Syringe", "relics/syringe.png", TIER, SOUND);
/*    */   }
/*    */   
/*    */   public String getUpdatedDescription()
/*    */   {
/* 23 */     return this.DESCRIPTIONS[0];
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int onPlayerHeal(int healAmount)
/*    */   {
/* 30 */     if ((healAmount > 0) && (AbstractDungeon.getCurrRoom().phase == com.megacrit.cardcrawl.rooms.AbstractRoom.RoomPhase.COMBAT)) {
/* 31 */       flash();
/* 32 */       AbstractDungeon.actionManager.addToBottom(new RelicAboveCreatureAction(AbstractDungeon.player, this));
/* 33 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageRandomEnemyAction(new com.megacrit.cardcrawl.cards.DamageInfo(AbstractDungeon.player, 6, com.megacrit.cardcrawl.cards.DamageInfo.DamageType.THORNS), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.POISON));
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 38 */     return healAmount;
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.relics.AbstractRelic makeCopy() {
/* 42 */     return new Syringe();
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\relics\Syringe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */