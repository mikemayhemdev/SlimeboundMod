/*    */ package gluttonmod.relics;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.RelicAboveCreatureAction;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic.LandingSound;
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic.RelicTier;
/*    */ import com.megacrit.cardcrawl.rooms.AbstractRoom;
/*    */ 
/*    */ public class AmuletOfPain extends AbstractGluttonRelic
/*    */ {
/*    */   public static final String ID = "AmuletOfPain";
/* 13 */   private static final AbstractRelic.RelicTier TIER = AbstractRelic.RelicTier.COMMON;
/*    */   private static final String IMG = "relics/amuletofpain.png";
/* 15 */   private static final AbstractRelic.LandingSound SOUND = AbstractRelic.LandingSound.CLINK;
/*    */   private static final int COUNT = 5;
/*    */   
/*    */   public AmuletOfPain() {
/* 19 */     super("AmuletOfPain", "relics/amuletofpain.png", TIER, SOUND);
/* 20 */     this.counter = 0;
/*    */   }
/*    */   
/*    */   public String getUpdatedDescription()
/*    */   {
/* 25 */     return this.DESCRIPTIONS[0];
/*    */   }
/*    */   
/*    */   public void onLoseHp(int damageAmount)
/*    */   {
/* 30 */     if ((damageAmount > 0) && (AbstractDungeon.getCurrRoom().phase == com.megacrit.cardcrawl.rooms.AbstractRoom.RoomPhase.COMBAT)) {
/* 31 */       this.counter += 1;
/* 32 */       if (this.counter == 5)
/*    */       {
/* 34 */         this.counter = 0;
/* 35 */         flash();
/* 36 */         this.pulse = false;
/* 37 */         AbstractDungeon.actionManager.addToBottom(new RelicAboveCreatureAction(AbstractDungeon.player, this));
/* 38 */         AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAllEnemiesAction(null, 
/* 39 */           com.megacrit.cardcrawl.cards.DamageInfo.createDamageMatrix(5, true), com.megacrit.cardcrawl.cards.DamageInfo.DamageType.THORNS, com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.SLASH_HEAVY));
/*    */ 
/*    */       }
/* 42 */       else if (this.counter == 4)
/*    */       {
/* 44 */         beginPulse();
/* 45 */         this.pulse = true;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void atBattleStart()
/*    */   {
/* 53 */     if (this.counter == 4)
/*    */     {
/* 55 */       beginPulse();
/* 56 */       this.pulse = true;
/*    */     }
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.relics.AbstractRelic makeCopy()
/*    */   {
/* 62 */     return new AmuletOfPain();
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\relics\AmuletOfPain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */