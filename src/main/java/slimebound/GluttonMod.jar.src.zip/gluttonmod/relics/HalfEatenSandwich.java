/*    */ package gluttonmod.relics;
/*    */ 
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic;
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic.LandingSound;
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic.RelicTier;
/*    */ 
/*    */ public class HalfEatenSandwich extends AbstractGluttonRelic
/*    */ {
/*    */   public static final String ID = "HalfEatenSandwich";
/* 12 */   private static final AbstractRelic.RelicTier TIER = AbstractRelic.RelicTier.UNCOMMON;
/*    */   private static final String IMG = "relics/sandwich.png";
/* 14 */   private static final AbstractRelic.LandingSound SOUND = AbstractRelic.LandingSound.FLAT;
/*    */   
/*    */   public HalfEatenSandwich() {
/* 17 */     super("HalfEatenSandwich", "relics/sandwich.png", TIER, SOUND);
/*    */   }
/*    */   
/*    */   public String getUpdatedDescription()
/*    */   {
/* 22 */     return this.DESCRIPTIONS[0];
/*    */   }
/*    */   
/*    */   public void onVictory()
/*    */   {
/* 27 */     flash();
/* 28 */     AbstractDungeon.actionManager.addToTop(new com.megacrit.cardcrawl.actions.common.RelicAboveCreatureAction(AbstractDungeon.player, this));
/* 29 */     AbstractPlayer p = AbstractDungeon.player;
/* 30 */     if (p.currentHealth > 0) {
/* 31 */       p.heal(2);
/*    */     }
/* 33 */     AbstractDungeon.player.increaseMaxHp(1, true);
/*    */   }
/*    */   
/*    */   public AbstractRelic makeCopy() {
/* 37 */     return new HalfEatenSandwich();
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\relics\HalfEatenSandwich.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */