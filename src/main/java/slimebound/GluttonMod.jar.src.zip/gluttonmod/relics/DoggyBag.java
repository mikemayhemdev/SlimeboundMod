/*    */ package gluttonmod.relics;
/*    */ 
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic.LandingSound;
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic.RelicTier;
/*    */ import com.megacrit.cardcrawl.rooms.AbstractRoom;
/*    */ 
/*    */ public class DoggyBag extends AbstractGluttonRelic
/*    */ {
/*    */   public static final String ID = "DoggyBag";
/* 11 */   private static final AbstractRelic.RelicTier TIER = AbstractRelic.RelicTier.BOSS;
/*    */   private static final String IMG = "relics/doggybag.png";
/* 13 */   private static final AbstractRelic.LandingSound SOUND = AbstractRelic.LandingSound.FLAT;
/*    */   
/*    */   public DoggyBag() {
/* 16 */     super("DoggyBag", "relics/doggybag.png", TIER, SOUND);
/*    */   }
/*    */   
/*    */   public String getUpdatedDescription()
/*    */   {
/* 21 */     return this.DESCRIPTIONS[0];
/*    */   }
/*    */   
/*    */   public void onEnterRoom(AbstractRoom room)
/*    */   {
/* 26 */     if ((room instanceof com.megacrit.cardcrawl.rooms.MonsterRoomElite))
/*    */     {
/* 28 */       this.pulse = true;
/* 29 */       beginPulse();
/*    */     }
/*    */     else
/*    */     {
/* 33 */       this.pulse = false;
/*    */     }
/*    */   }
/*    */   
/*    */   public void onVictory()
/*    */   {
/* 39 */     if ((AbstractDungeon.getCurrRoom() instanceof com.megacrit.cardcrawl.rooms.MonsterRoomElite))
/*    */     {
/* 41 */       flash();
/* 42 */       this.pulse = false;
/* 43 */       AbstractDungeon.actionManager.addToTop(new com.megacrit.cardcrawl.actions.common.RelicAboveCreatureAction(AbstractDungeon.player, this));
/* 44 */       AbstractDungeon.player.increaseMaxHp(10, true);
/*    */     }
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.relics.AbstractRelic makeCopy() {
/* 49 */     return new DoggyBag();
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\relics\DoggyBag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */