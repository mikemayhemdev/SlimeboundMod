/*    */ package gluttonmod.relics;
/*    */ 
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic.RelicTier;
/*    */ 
/*    */ public class Lollipop extends AbstractGluttonRelic {
/*    */   public static final String ID = "Lollipop";
/*  7 */   private static final AbstractRelic.RelicTier TIER = AbstractRelic.RelicTier.SHOP;
/*    */   private static final String IMG = "relics/lollipop.png";
/*  9 */   private static final com.megacrit.cardcrawl.relics.AbstractRelic.LandingSound SOUND = com.megacrit.cardcrawl.relics.AbstractRelic.LandingSound.CLINK;
/*    */   
/*    */   public Lollipop() {
/* 12 */     super("Lollipop", "relics/lollipop.png", TIER, SOUND);
/*    */   }
/*    */   
/*    */   public String getUpdatedDescription()
/*    */   {
/* 17 */     return this.DESCRIPTIONS[0];
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.relics.AbstractRelic makeCopy() {
/* 21 */     return new Lollipop();
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\relics\Lollipop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */