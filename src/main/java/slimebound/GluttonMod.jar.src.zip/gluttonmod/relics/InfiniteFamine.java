/*    */ package gluttonmod.relics;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic;
/*    */ 
/*    */ public class InfiniteFamine extends AbstractGluttonRelic
/*    */ {
/*    */   public static final String ID = "InfiniteFamine";
/* 11 */   private static final com.megacrit.cardcrawl.relics.AbstractRelic.RelicTier TIER = com.megacrit.cardcrawl.relics.AbstractRelic.RelicTier.BOSS;
/*    */   private static final String IMG = "relics/infinitefamine.png";
/* 13 */   private static final com.megacrit.cardcrawl.relics.AbstractRelic.LandingSound SOUND = com.megacrit.cardcrawl.relics.AbstractRelic.LandingSound.HEAVY;
/*    */   
/*    */   public InfiniteFamine() {
/* 16 */     super("InfiniteFamine", "relics/infinitefamine.png", TIER, SOUND);
/*    */   }
/*    */   
/*    */   public String getUpdatedDescription()
/*    */   {
/* 21 */     return this.DESCRIPTIONS[0];
/*    */   }
/*    */   
/*    */   public void atTurnStartPostDraw()
/*    */   {
/* 26 */     AbstractRelic lollipop = AbstractDungeon.player.getRelic("Lollipop");
/* 27 */     int damage = 2;
/* 28 */     if (lollipop != null) {
/* 29 */       damage--;
/*    */     }
/* 31 */     if (AbstractDungeon.player.currentHealth > damage) {
/* 32 */       flash();
/* 33 */       if (lollipop != null) {
/* 34 */         lollipop.flash();
/*    */       }
/* 36 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.RelicAboveCreatureAction(AbstractDungeon.player, this));
/* 37 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.LoseHPAction(AbstractDungeon.player, AbstractDungeon.player, damage));
/*    */       
/* 39 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DrawCardAction(AbstractDungeon.player, 2));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void obtain()
/*    */   {
/* 46 */     if (AbstractDungeon.player.hasRelic("EternalHunger")) {
/* 47 */       for (int i = 0; i < AbstractDungeon.player.relics.size(); i++) {
/* 48 */         if (((AbstractRelic)AbstractDungeon.player.relics.get(i)).relicId.equals("EternalHunger")) {
/* 49 */           instantObtain(AbstractDungeon.player, i, true);
/* 50 */           break;
/*    */         }
/*    */       }
/*    */     } else {
/* 54 */       super.obtain();
/*    */     }
/*    */   }
/*    */   
/*    */   public AbstractRelic makeCopy() {
/* 59 */     return new InfiniteFamine();
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\relics\InfiniteFamine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */