/*    */ package gluttonmod.powers;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.core.AbstractCreature;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import com.megacrit.cardcrawl.powers.PoisonPower;
/*    */ 
/*    */ public class StarvationModePower extends AbstractGluttonPower
/*    */ {
/*    */   public static final String POWER_ID = "StarvationMode";
/*    */   public static final String NAME = "Starvation Mode";
/* 15 */   public static final String[] DESCRIPTIONS = { "Whenever you draw a status or curse, apply #b", " #yPoison to ALL enemies." };
/*    */   public static final String IMG = "powers/starvationmode.png";
/*    */   
/*    */   public StarvationModePower(AbstractCreature owner, int amount) {
/* 19 */     this.name = "Starvation Mode";
/* 20 */     this.ID = "StarvationMode";
/* 21 */     this.owner = owner;
/*    */     
/* 23 */     this.img = new com.badlogic.gdx.graphics.Texture(gluttonmod.GluttonMod.getResourcePath("powers/starvationmode.png"));
/* 24 */     this.type = com.megacrit.cardcrawl.powers.AbstractPower.PowerType.BUFF;
/* 25 */     this.amount = amount;
/* 26 */     updateDescription();
/*    */   }
/*    */   
/*    */   public void updateDescription()
/*    */   {
/* 31 */     this.description = (DESCRIPTIONS[0] + this.amount + DESCRIPTIONS[1]);
/*    */   }
/*    */   
/*    */   public void onCardDraw(AbstractCard card)
/*    */   {
/* 36 */     if ((card.type == AbstractCard.CardType.STATUS) || (card.type == AbstractCard.CardType.CURSE))
/*    */     {
/* 38 */       flash();
/* 39 */       for (AbstractMonster m : AbstractDungeon.getMonsters().monsters) {
/* 40 */         if ((!m.isDead) && (!m.isDying)) {
/* 41 */           AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.ApplyPowerAction(m, this.owner, new PoisonPower(m, this.owner, this.amount), this.amount));
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\powers\StarvationModePower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */