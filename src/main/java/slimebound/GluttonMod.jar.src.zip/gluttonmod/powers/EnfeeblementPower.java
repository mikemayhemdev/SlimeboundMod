/*    */ package gluttonmod.powers;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.unique.SwordBoomerangAction;
/*    */ import com.megacrit.cardcrawl.core.AbstractCreature;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.MonsterGroup;
/*    */ import com.megacrit.cardcrawl.powers.AbstractPower;
/*    */ import com.megacrit.cardcrawl.powers.AbstractPower.PowerType;
/*    */ import gluttonmod.GluttonMod;
/*    */ 
/*    */ public class EnfeeblementPower extends AbstractGluttonPower implements com.evacipated.cardcrawl.mod.stslib.powers.interfaces.OnReceivePowerPower
/*    */ {
/*    */   public static final String POWER_ID = "Enfeeblement";
/*    */   public static final String NAME = "Enfeeblement";
/* 16 */   public static final String[] DESCRIPTIONS = { "Whenever you gain a debuff, deal #b", " damage to a random enemy." };
/*    */   public static final String IMG = "powers/enfeeblement.png";
/*    */   
/*    */   public EnfeeblementPower(AbstractCreature owner, int amount)
/*    */   {
/* 21 */     this.name = "Enfeeblement";
/* 22 */     this.ID = "Enfeeblement";
/* 23 */     this.owner = owner;
/*    */     
/* 25 */     this.img = new com.badlogic.gdx.graphics.Texture(GluttonMod.getResourcePath("powers/enfeeblement.png"));
/* 26 */     this.type = AbstractPower.PowerType.BUFF;
/* 27 */     this.amount = amount;
/* 28 */     updateDescription();
/*    */   }
/*    */   
/*    */   public void updateDescription()
/*    */   {
/* 33 */     this.description = (DESCRIPTIONS[0] + this.amount + DESCRIPTIONS[1]);
/*    */   }
/*    */   
/*    */   public void atStartOfTurnPostDraw()
/*    */   {
/* 38 */     if (GluttonMod.hasDebuff(this.owner)) {
/* 39 */       flash();
/* 40 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DrawCardAction(this.owner, this.amount));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean onReceivePower(AbstractPower power, AbstractCreature target, AbstractCreature source)
/*    */   {
/* 46 */     if (power.type == AbstractPower.PowerType.DEBUFF) {
/* 47 */       flash();
/* 48 */       AbstractDungeon.actionManager.addToBottom(new SwordBoomerangAction(
/* 49 */         AbstractDungeon.getMonsters().getRandomMonster(true), new com.megacrit.cardcrawl.cards.DamageInfo(this.owner, this.amount, com.megacrit.cardcrawl.cards.DamageInfo.DamageType.THORNS), 1));
/*    */     }
/*    */     
/* 52 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\powers\EnfeeblementPower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */