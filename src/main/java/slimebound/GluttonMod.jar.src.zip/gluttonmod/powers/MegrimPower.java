/*    */ package gluttonmod.powers;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.unique.SwordBoomerangAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.core.AbstractCreature;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.MonsterGroup;
/*    */ 
/*    */ public class MegrimPower extends AbstractGluttonPower
/*    */ {
/*    */   public static final String POWER_ID = "Megrim";
/*    */   public static final String NAME = "Megrim";
/* 14 */   public static final String[] DESCRIPTIONS = { "Whenever you draw a card, deal #b", " damage to a random enemy." };
/*    */   public static final String IMG = "powers/megrim.png";
/*    */   
/*    */   public MegrimPower(AbstractCreature owner, int amount) {
/* 18 */     this.name = "Megrim";
/* 19 */     this.ID = "Megrim";
/* 20 */     this.owner = owner;
/*    */     
/* 22 */     this.img = new com.badlogic.gdx.graphics.Texture(gluttonmod.GluttonMod.getResourcePath("powers/megrim.png"));
/* 23 */     this.type = com.megacrit.cardcrawl.powers.AbstractPower.PowerType.BUFF;
/* 24 */     this.amount = amount;
/* 25 */     updateDescription();
/*    */   }
/*    */   
/*    */   public void updateDescription()
/*    */   {
/* 30 */     this.description = (DESCRIPTIONS[0] + this.amount + DESCRIPTIONS[1]);
/*    */   }
/*    */   
/*    */   public void onCardDraw(AbstractCard card)
/*    */   {
/* 35 */     flash();
/* 36 */     AbstractDungeon.actionManager.addToBottom(new SwordBoomerangAction(
/* 37 */       AbstractDungeon.getMonsters().getRandomMonster(true), new com.megacrit.cardcrawl.cards.DamageInfo(this.owner, this.amount, com.megacrit.cardcrawl.cards.DamageInfo.DamageType.THORNS), 1));
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\powers\MegrimPower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */