/*    */ package gluttonmod.powers;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.core.AbstractCreature;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.MonsterGroup;
/*    */ import com.megacrit.cardcrawl.rooms.AbstractRoom;
/*    */ import gluttonmod.GluttonMod;
/*    */ 
/*    */ public class BleedPower extends AbstractGluttonPower
/*    */ {
/*    */   public static final String POWER_ID = "Bleed";
/*    */   public static final String NAME = "Bleed";
/* 14 */   public static final String[] DESCRIPTIONS = { "At the start of your turn, lose #b", " HP.", "At the start of its turn, loses #b" };
/*    */   
/*    */   public static final String IMG = "powers/bleed.png";
/*    */   
/*    */   private AbstractCreature source;
/*    */   
/*    */ 
/*    */   public BleedPower(AbstractCreature owner, AbstractCreature source, int amount)
/*    */   {
/* 23 */     this.name = "Bleed";
/* 24 */     this.ID = "Bleed";
/* 25 */     this.owner = owner;
/* 26 */     this.source = source;
/*    */     
/* 28 */     this.img = new com.badlogic.gdx.graphics.Texture(GluttonMod.getResourcePath("powers/bleed.png"));
/* 29 */     this.type = com.megacrit.cardcrawl.powers.AbstractPower.PowerType.DEBUFF;
/* 30 */     this.amount = amount;
/* 31 */     updateDescription();
/*    */   }
/*    */   
/*    */   public void updateDescription()
/*    */   {
/* 36 */     if ((this.owner == null) || (this.owner.isPlayer)) {
/* 37 */       this.description = (DESCRIPTIONS[0] + this.amount + DESCRIPTIONS[1]);
/*    */     } else {
/* 39 */       this.description = (DESCRIPTIONS[2] + this.amount + DESCRIPTIONS[1]);
/*    */     }
/*    */   }
/*    */   
/*    */   public void atStartOfTurn()
/*    */   {
/* 45 */     if ((AbstractDungeon.getCurrRoom().phase == com.megacrit.cardcrawl.rooms.AbstractRoom.RoomPhase.COMBAT) && 
/* 46 */       (!AbstractDungeon.getMonsters().areMonstersBasicallyDead()))
/*    */     {
/* 48 */       flashWithoutSound();
/* 49 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.LoseHPAction(this.owner, this.source, this.amount, com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.FIRE));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\powers\BleedPower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */