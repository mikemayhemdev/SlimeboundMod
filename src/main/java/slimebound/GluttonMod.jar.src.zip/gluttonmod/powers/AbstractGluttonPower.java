/*    */ package gluttonmod.powers;
/*    */ 
/*    */ import basemod.ReflectionHacks;
/*    */ import com.badlogic.gdx.graphics.Color;
/*    */ import com.badlogic.gdx.graphics.g2d.SpriteBatch;
/*    */ import com.badlogic.gdx.graphics.g2d.TextureAtlas.AtlasRegion;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.core.Settings;
/*    */ import com.megacrit.cardcrawl.powers.AbstractPower;
/*    */ import com.megacrit.cardcrawl.vfx.AbstractGameEffect;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public abstract class AbstractGluttonPower extends AbstractPower
/*    */ {
/* 15 */   protected Color renderColor = null;
/*    */   
/*    */   public void onCardDraw(AbstractCard card) {}
/*    */   
/*    */   public void renderIcons(SpriteBatch sb, float x, float y, Color c)
/*    */   {
/* 21 */     if (this.renderColor == null) {
/* 22 */       sb.setColor(c);
/*    */     } else {
/* 24 */       sb.setColor(this.renderColor);
/*    */     }
/*    */     
/* 27 */     if (this.img != null) {
/* 28 */       sb.draw(this.img, x - 12.0F, y - 12.0F, 16.0F, 16.0F, 32.0F, 32.0F, Settings.scale, Settings.scale, 0.0F, 0, 0, 32, 32, false, false);
/*    */     } else {
/* 30 */       sb.draw(this.region48, x - this.region48.packedWidth / 2.0F, y - this.region48.packedHeight / 2.0F, this.region48.packedWidth / 2.0F, this.region48.packedHeight / 2.0F, this.region48.packedWidth, this.region48.packedHeight, Settings.scale, Settings.scale, 0.0F);
/*    */     }
/*    */     
/* 33 */     ArrayList<AbstractGameEffect> effectList = (ArrayList)ReflectionHacks.getPrivate(this, AbstractPower.class, "effect");
/* 34 */     for (AbstractGameEffect e : effectList) {
/* 35 */       e.render(sb, x, y);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\powers\AbstractGluttonPower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */