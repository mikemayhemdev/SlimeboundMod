/*    */ package gluttonmod.powers;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.HealAction;
/*    */ import com.megacrit.cardcrawl.actions.common.RemoveSpecificPowerAction;
/*    */ import com.megacrit.cardcrawl.core.AbstractCreature;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.powers.AbstractPower.PowerType;
/*    */ import gluttonmod.GluttonMod;
/*    */ 
/*    */ public class ClotPower extends AbstractGluttonPower
/*    */ {
/*    */   private static final int CLOT_HEAL = 3;
/*    */   public static final String POWER_ID = "Clot";
/*    */   public static final String NAME = "Clot";
/* 16 */   public static final String[] DESCRIPTIONS = { "Heal #b", " HP at the start of each turn for #b", " turn.", " turns." };
/*    */   public static final String IMG = "powers/clot.png";
/*    */   
/*    */   public ClotPower(AbstractCreature owner, int amount)
/*    */   {
/* 21 */     this.name = "Clot";
/* 22 */     this.ID = "Clot";
/* 23 */     this.owner = owner;
/*    */     
/* 25 */     this.img = new com.badlogic.gdx.graphics.Texture(GluttonMod.getResourcePath("powers/clot.png"));
/* 26 */     this.type = AbstractPower.PowerType.BUFF;
/* 27 */     this.amount = amount;
/* 28 */     updateDescription();
/*    */     
/* 30 */     this.isTurnBased = true;
/*    */   }
/*    */   
/*    */   public void updateDescription()
/*    */   {
/* 35 */     if (this.amount == 1) {
/* 36 */       this.description = (DESCRIPTIONS[0] + 3 + DESCRIPTIONS[1] + this.amount + DESCRIPTIONS[2]);
/*    */     }
/*    */     else {
/* 39 */       this.description = (DESCRIPTIONS[0] + 3 + DESCRIPTIONS[1] + this.amount + DESCRIPTIONS[3]);
/*    */     }
/*    */   }
/*    */   
/*    */   public void atStartOfTurn()
/*    */   {
/* 45 */     flash();
/* 46 */     AbstractDungeon.actionManager.addToBottom(new HealAction(this.owner, this.owner, 3));
/* 47 */     if (this.amount == 0) {
/* 48 */       AbstractDungeon.actionManager.addToBottom(new RemoveSpecificPowerAction(this.owner, this.owner, "Clot"));
/*    */     } else {
/* 50 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.ReducePowerAction(this.owner, this.owner, "Clot", 1));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\powers\ClotPower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */