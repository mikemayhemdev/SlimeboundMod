/*    */ package gluttonmod.powers;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.core.AbstractCreature;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import com.megacrit.cardcrawl.monsters.MonsterGroup;
/*    */ import com.megacrit.cardcrawl.powers.PoisonPower;
/*    */ 
/*    */ public class ToxicResiduePower extends AbstractGluttonPower
/*    */ {
/*    */   public static final String POWER_ID = "ToxicResidue";
/*    */   public static final String NAME = "Toxic Residue";
/* 15 */   public static final String[] DESCRIPTIONS = { "Whenever a card is #yExhausted, apply #b", " #yPoison to a random enemy." };
/*    */   public static final String IMG = "powers/toxicresidue.png";
/*    */   
/*    */   public ToxicResiduePower(AbstractCreature owner, int amount)
/*    */   {
/* 20 */     this.name = "Toxic Residue";
/* 21 */     this.ID = "ToxicResidue";
/* 22 */     this.owner = owner;
/*    */     
/* 24 */     this.img = new com.badlogic.gdx.graphics.Texture(gluttonmod.GluttonMod.getResourcePath("powers/toxicresidue.png"));
/* 25 */     this.type = com.megacrit.cardcrawl.powers.AbstractPower.PowerType.BUFF;
/* 26 */     this.amount = amount;
/* 27 */     updateDescription();
/*    */   }
/*    */   
/*    */   public void updateDescription()
/*    */   {
/* 32 */     this.description = (DESCRIPTIONS[0] + this.amount + DESCRIPTIONS[1]);
/*    */   }
/*    */   
/*    */   public void onExhaust(AbstractCard card)
/*    */   {
/* 37 */     flash();
/* 38 */     AbstractMonster randomMonster = AbstractDungeon.getMonsters().getRandomMonster(true);
/* 39 */     if (randomMonster != null) {
/* 40 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.ApplyPowerAction(randomMonster, this.owner, new PoisonPower(randomMonster, this.owner, this.amount), this.amount));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\powers\ToxicResiduePower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */