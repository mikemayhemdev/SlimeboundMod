/*    */ package gluttonmod.powers;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.MakeTempCardInDiscardAction;
/*    */ import com.megacrit.cardcrawl.core.AbstractCreature;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import gluttonmod.GluttonMod;
/*    */ 
/*    */ public class StarvingPower extends AbstractGluttonPower
/*    */ {
/*    */   public static final String POWER_ID = "Starving";
/*    */   public static final String NAME = "Starving";
/* 13 */   public static final String[] DESCRIPTIONS = { "At the start of your turn, shuffle #b", " #yHunger #yPang into your discard pile.", " #yHunger #yPangs into your discard pile." };
/*    */   
/*    */ 
/*    */   public static final String IMG = "powers/starving.png";
/*    */   
/*    */ 
/*    */   public StarvingPower(AbstractCreature owner, int amount)
/*    */   {
/* 21 */     this.name = "Starving";
/* 22 */     this.ID = "Starving";
/* 23 */     this.owner = owner;
/*    */     
/* 25 */     this.img = new com.badlogic.gdx.graphics.Texture(GluttonMod.getResourcePath("powers/starving.png"));
/* 26 */     this.type = com.megacrit.cardcrawl.powers.AbstractPower.PowerType.DEBUFF;
/* 27 */     this.amount = amount;
/* 28 */     updateDescription();
/*    */   }
/*    */   
/*    */   public void updateDescription()
/*    */   {
/* 33 */     if (this.amount == 1) {
/* 34 */       this.description = (DESCRIPTIONS[0] + this.amount + DESCRIPTIONS[1]);
/*    */     }
/*    */     else {
/* 37 */       this.description = (DESCRIPTIONS[0] + this.amount + DESCRIPTIONS[2]);
/*    */     }
/*    */   }
/*    */   
/*    */   public void atStartOfTurn()
/*    */   {
/* 43 */     flash();
/* 44 */     AbstractDungeon.actionManager.addToBottom(new MakeTempCardInDiscardAction(new gluttonmod.cards.HungerPang(), this.amount));
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\powers\StarvingPower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */