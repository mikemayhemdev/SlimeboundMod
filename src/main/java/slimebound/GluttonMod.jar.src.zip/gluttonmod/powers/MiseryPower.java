/*    */ package gluttonmod.powers;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.animations.VFXAction;
/*    */ import com.megacrit.cardcrawl.actions.common.DamageAllEnemiesAction;
/*    */ import com.megacrit.cardcrawl.cards.DamageInfo;
/*    */ import com.megacrit.cardcrawl.core.AbstractCreature;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.powers.AbstractPower.PowerType;
/*    */ import com.megacrit.cardcrawl.vfx.combat.CleaveEffect;
/*    */ import gluttonmod.GluttonMod;
/*    */ 
/*    */ public class MiseryPower extends AbstractGluttonPower
/*    */ {
/*    */   public static final String POWER_ID = "Misery";
/*    */   public static final String NAME = "Misery";
/* 17 */   public static final String[] DESCRIPTIONS = { "Whenever you lose HP, deal", "damage to ALL enemies." };
/*    */   public static final String IMG = "powers/misery.png";
/*    */   
/*    */   public MiseryPower(AbstractCreature owner, int amount) {
/* 21 */     this.name = "Misery";
/* 22 */     this.ID = "Misery";
/* 23 */     this.owner = owner;
/*    */     
/* 25 */     this.img = new com.badlogic.gdx.graphics.Texture(GluttonMod.getResourcePath("powers/misery.png"));
/* 26 */     this.type = AbstractPower.PowerType.BUFF;
/* 27 */     this.amount = amount;
/* 28 */     updateDescription();
/*    */   }
/*    */   
/*    */   public void updateDescription()
/*    */   {
/* 33 */     this.description = (DESCRIPTIONS[0] + " " + this.amount + " " + DESCRIPTIONS[1]);
/*    */   }
/*    */   
/*    */   public int onLoseHp(int damageAmount)
/*    */   {
/* 38 */     flash();
/* 39 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.utility.SFXAction("ATTACK_HEAVY"));
/* 40 */     AbstractDungeon.actionManager.addToBottom(new VFXAction(this.owner, new CleaveEffect(), 0.25F));
/* 41 */     AbstractDungeon.actionManager.addToBottom(new DamageAllEnemiesAction(this.owner, 
/* 42 */       DamageInfo.createDamageMatrix(this.amount, true), com.megacrit.cardcrawl.cards.DamageInfo.DamageType.THORNS, com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.NONE));
/*    */     
/* 44 */     return damageAmount;
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\powers\MiseryPower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */