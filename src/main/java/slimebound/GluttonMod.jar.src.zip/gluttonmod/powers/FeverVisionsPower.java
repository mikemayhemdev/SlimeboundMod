/*    */ package gluttonmod.powers;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.core.AbstractCreature;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import gluttonmod.GluttonMod;
/*    */ 
/*    */ public class FeverVisionsPower extends AbstractGluttonPower
/*    */ {
/*    */   public static final String POWER_ID = "FeverVisions";
/*    */   public static final String NAME = "Fever Visions";
/* 12 */   public static final String[] DESCRIPTIONS = { "At the start of your turn, if you have a debuff, draw #b", "card.", "cards." };
/*    */   public static final String IMG = "powers/fevervisions.png";
/*    */   
/*    */   public FeverVisionsPower(AbstractCreature owner, int amount)
/*    */   {
/* 17 */     this.name = "Fever Visions";
/* 18 */     this.ID = "FeverVisions";
/* 19 */     this.owner = owner;
/*    */     
/* 21 */     this.img = new com.badlogic.gdx.graphics.Texture(GluttonMod.getResourcePath("powers/fevervisions.png"));
/* 22 */     this.type = com.megacrit.cardcrawl.powers.AbstractPower.PowerType.BUFF;
/* 23 */     this.amount = amount;
/* 24 */     updateDescription();
/*    */   }
/*    */   
/*    */   public void updateDescription()
/*    */   {
/* 29 */     if (this.amount == 1) {
/* 30 */       this.description = (DESCRIPTIONS[0] + this.amount + " " + DESCRIPTIONS[1]);
/*    */     }
/*    */     else {
/* 33 */       this.description = (DESCRIPTIONS[0] + this.amount + " " + DESCRIPTIONS[2]);
/*    */     }
/*    */   }
/*    */   
/*    */   public void atStartOfTurnPostDraw()
/*    */   {
/* 39 */     if (GluttonMod.hasDebuff(this.owner)) {
/* 40 */       flash();
/* 41 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DrawCardAction(this.owner, this.amount));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\powers\FeverVisionsPower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */