/*    */ package gluttonmod.powers;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.core.AbstractCreature;
/*    */ import gluttonmod.actions.MakeEchoAction;
/*    */ 
/*    */ public class NostalgiaPower extends AbstractGluttonPower
/*    */ {
/*    */   public static final String POWER_ID = "Nostalgia";
/*    */   public static final String NAME = "Nostalgia";
/* 13 */   public static final String[] DESCRIPTIONS = { "Whenever you exhaust a non-ethereal Skill or Attack, create", "an echo of it.", "echoes of it." };
/*    */   public static final String IMG = "powers/nostalgia.png";
/*    */   
/*    */   public NostalgiaPower(AbstractCreature owner, int amount)
/*    */   {
/* 18 */     this.name = "Nostalgia";
/* 19 */     this.ID = "Nostalgia";
/* 20 */     this.owner = owner;
/*    */     
/* 22 */     this.img = new com.badlogic.gdx.graphics.Texture(gluttonmod.GluttonMod.getResourcePath("powers/nostalgia.png"));
/* 23 */     this.type = com.megacrit.cardcrawl.powers.AbstractPower.PowerType.BUFF;
/* 24 */     this.amount = amount;
/* 25 */     updateDescription();
/*    */   }
/*    */   
/*    */   public void updateDescription()
/*    */   {
/* 30 */     if (this.amount == 1) {
/* 31 */       this.description = (DESCRIPTIONS[0] + " " + DESCRIPTIONS[1]);
/*    */     }
/*    */     else {
/* 34 */       this.description = (DESCRIPTIONS[0] + " " + this.amount + " " + DESCRIPTIONS[2]);
/*    */     }
/*    */   }
/*    */   
/*    */   public void onExhaust(AbstractCard card)
/*    */   {
/* 40 */     if ((card.type == AbstractCard.CardType.ATTACK) || (card.type == AbstractCard.CardType.SKILL))
/*    */     {
/* 42 */       if (!card.isEthereal) {
/* 43 */         flash();
/* 44 */         com.megacrit.cardcrawl.dungeons.AbstractDungeon.actionManager.addToBottom(new MakeEchoAction(card, this.amount));
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\powers\NostalgiaPower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */