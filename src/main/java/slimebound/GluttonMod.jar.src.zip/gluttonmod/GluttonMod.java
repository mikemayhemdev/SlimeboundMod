/*     */ package gluttonmod;
/*     */ 
/*     */ import basemod.BaseMod;
/*     */ import basemod.interfaces.EditStringsSubscriber;
/*     */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*     */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*     */ import com.megacrit.cardcrawl.core.AbstractCreature;
/*     */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*     */ import com.megacrit.cardcrawl.powers.AbstractPower;
/*     */ import com.megacrit.cardcrawl.rooms.AbstractRoom;
/*     */ import gluttonmod.cards.Avarice;
/*     */ import gluttonmod.cards.Bite_Glutton;
/*     */ import gluttonmod.cards.BloodyKnuckle;
/*     */ import gluttonmod.cards.Brace;
/*     */ import gluttonmod.cards.Dispepsia;
/*     */ import gluttonmod.cards.Enfeeblement;
/*     */ import gluttonmod.cards.GnawingHunger;
/*     */ import gluttonmod.cards.HungerPang;
/*     */ import gluttonmod.cards.KneeJerk;
/*     */ import gluttonmod.cards.Malignancy;
/*     */ import gluttonmod.cards.SelfFlagellate;
/*     */ import gluttonmod.cards.ShareWeakness;
/*     */ import gluttonmod.cards.Tantrum;
/*     */ import gluttonmod.cards.Toxicity;
/*     */ import gluttonmod.cards.Treat;
/*     */ import gluttonmod.patches.AbstractCardEnum;
/*     */ import gluttonmod.powers.AbstractGluttonPower;
/*     */ import gluttonmod.relics.AmuletOfPain;
/*     */ import gluttonmod.relics.HalfEatenSandwich;
/*     */ import gluttonmod.relics.Lollipop;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ @com.evacipated.cardcrawl.modthespire.lib.SpireInitializer
/*     */ public class GluttonMod implements basemod.interfaces.EditCharactersSubscriber, basemod.interfaces.EditRelicsSubscriber, basemod.interfaces.EditCardsSubscriber, EditStringsSubscriber, basemod.interfaces.EditKeywordsSubscriber, basemod.interfaces.PostDrawSubscriber, basemod.interfaces.OnStartBattleSubscriber
/*     */ {
/*  37 */   private static final com.badlogic.gdx.graphics.Color GLUTTON_COLOR = com.megacrit.cardcrawl.helpers.CardHelper.getColor(75.0F, 175.0F, 75.0F);
/*     */   
/*     */   private static final String ASSETS_FOLDER = "images";
/*     */   
/*     */   private static final String ATTACK_CARD = "512/bg_attack_glutton.png";
/*     */   private static final String SKILL_CARD = "512/bg_skill_glutton.png";
/*     */   private static final String POWER_CARD = "512/bg_power_glutton.png";
/*     */   private static final String ENERGY_ORB = "512/card_glutton_orb.png";
/*     */   private static final String ATTACK_CARD_PORTRAIT = "1024/bg_attack_glutton.png";
/*     */   private static final String SKILL_CARD_PORTRAIT = "1024/bg_skill_glutton.png";
/*     */   private static final String POWER_CARD_PORTRAIT = "1024/bg_power_glutton.png";
/*     */   private static final String ENERGY_ORB_PORTRAIT = "1024/card_glutton_orb.png";
/*     */   private static final String CHAR_BUTTON = "charSelect/button.png";
/*     */   private static final String CHAR_PORTRAIT = "charSelect/portrait.png";
/*     */   
/*     */   public static final String getResourcePath(String resource)
/*     */   {
/*  54 */     return "images/" + resource;
/*     */   }
/*     */   
/*  57 */   public static final Logger logger = LogManager.getLogger(GluttonMod.class);
/*     */   
/*     */   public GluttonMod() {
/*  60 */     BaseMod.subscribe(this);
/*     */     
/*  62 */     BaseMod.addColor(AbstractCardEnum.GLUTTON, GLUTTON_COLOR, GLUTTON_COLOR, GLUTTON_COLOR, GLUTTON_COLOR, GLUTTON_COLOR, GLUTTON_COLOR, GLUTTON_COLOR, 
/*     */     
/*  64 */       getResourcePath("512/bg_attack_glutton.png"), getResourcePath("512/bg_skill_glutton.png"), getResourcePath("512/bg_power_glutton.png"), 
/*  65 */       getResourcePath("512/card_glutton_orb.png"), getResourcePath("1024/bg_attack_glutton.png"), 
/*  66 */       getResourcePath("1024/bg_skill_glutton.png"), getResourcePath("1024/bg_power_glutton.png"), 
/*  67 */       getResourcePath("1024/card_glutton_orb.png"));
/*     */   }
/*     */   
/*     */   public static void initialize() {
/*  71 */     new GluttonMod();
/*     */   }
/*     */   
/*     */   public void receiveEditCharacters()
/*     */   {
/*  76 */     BaseMod.addCharacter(new gluttonmod.characters.GluttonCharacter("The Glutton"), 
/*  77 */       getResourcePath("charSelect/button.png"), 
/*  78 */       getResourcePath("charSelect/portrait.png"), gluttonmod.patches.GluttonEnum.GLUTTON);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void receiveEditRelics()
/*     */   {
/*  85 */     BaseMod.addRelicToCustomPool(new gluttonmod.relics.EternalHunger(), AbstractCardEnum.GLUTTON);
/*     */     
/*     */ 
/*  88 */     BaseMod.addRelicToCustomPool(new AmuletOfPain(), AbstractCardEnum.GLUTTON);
/*     */     
/*     */ 
/*  91 */     BaseMod.addRelicToCustomPool(new HalfEatenSandwich(), AbstractCardEnum.GLUTTON);
/*     */     
/*     */ 
/*  94 */     BaseMod.addRelicToCustomPool(new gluttonmod.relics.Syringe(), AbstractCardEnum.GLUTTON);
/*     */     
/*     */ 
/*  97 */     BaseMod.addRelicToCustomPool(new gluttonmod.relics.DoggyBag(), AbstractCardEnum.GLUTTON);
/*  98 */     BaseMod.addRelicToCustomPool(new gluttonmod.relics.Gemstone(), AbstractCardEnum.GLUTTON);
/*  99 */     BaseMod.addRelicToCustomPool(new gluttonmod.relics.InfiniteFamine(), AbstractCardEnum.GLUTTON);
/*     */     
/*     */ 
/* 102 */     BaseMod.addRelicToCustomPool(new Lollipop(), AbstractCardEnum.GLUTTON);
/*     */   }
/*     */   
/*     */ 
/*     */   public void receiveEditCards()
/*     */   {
/* 108 */     BaseMod.addCard(new HungerPang());
/*     */     
/*     */ 
/* 111 */     BaseMod.addCard(new gluttonmod.cards.Defend_Glutton());
/* 112 */     BaseMod.addCard(new gluttonmod.cards.Strike_Glutton());
/* 113 */     BaseMod.addCard(new gluttonmod.cards.Flail());
/*     */     
/*     */ 
/*     */ 
/* 117 */     BaseMod.addCard(new Bite_Glutton());
/* 118 */     BaseMod.addCard(new gluttonmod.cards.Borborygmi());
/* 119 */     BaseMod.addCard(new gluttonmod.cards.Chomp());
/* 120 */     BaseMod.addCard(new gluttonmod.cards.Demolish());
/* 121 */     BaseMod.addCard(new gluttonmod.cards.Devour());
/* 122 */     BaseMod.addCard(new gluttonmod.cards.Feed_Glutton());
/* 123 */     BaseMod.addCard(new GnawingHunger());
/* 124 */     BaseMod.addCard(new KneeJerk());
/* 125 */     BaseMod.addCard(new gluttonmod.cards.Slam());
/* 126 */     BaseMod.addCard(new Tantrum());
/*     */     
/* 128 */     BaseMod.addCard(new Brace());
/* 129 */     BaseMod.addCard(new gluttonmod.cards.GuardStance());
/* 130 */     BaseMod.addCard(new gluttonmod.cards.PainMeditation());
/* 131 */     BaseMod.addCard(new gluttonmod.cards.Rest());
/* 132 */     BaseMod.addCard(new gluttonmod.cards.Salivate());
/* 133 */     BaseMod.addCard(new gluttonmod.cards.Scab());
/* 134 */     BaseMod.addCard(new SelfFlagellate());
/* 135 */     BaseMod.addCard(new gluttonmod.cards.Thrombosis());
/* 136 */     BaseMod.addCard(new Treat());
/* 137 */     BaseMod.addCard(new gluttonmod.cards.Yearn());
/*     */     
/*     */ 
/*     */ 
/* 141 */     BaseMod.addCard(new gluttonmod.cards.BellySlam());
/* 142 */     BaseMod.addCard(new BloodyKnuckle());
/* 143 */     BaseMod.addCard(new gluttonmod.cards.DecrepitStrike());
/* 144 */     BaseMod.addCard(new gluttonmod.cards.DistilledAgony());
/* 145 */     BaseMod.addCard(new gluttonmod.cards.FeebleKick());
/* 146 */     BaseMod.addCard(new gluttonmod.cards.LashOut());
/* 147 */     BaseMod.addCard(new gluttonmod.cards.Mug());
/* 148 */     BaseMod.addCard(new gluttonmod.cards.Overreach());
/* 149 */     BaseMod.addCard(new gluttonmod.cards.Profligacy());
/* 150 */     BaseMod.addCard(new gluttonmod.cards.Strain());
/* 151 */     BaseMod.addCard(new gluttonmod.cards.Throb());
/* 152 */     BaseMod.addCard(new gluttonmod.cards.Torment());
/* 153 */     BaseMod.addCard(new gluttonmod.cards.Voracity());
/*     */     
/* 155 */     BaseMod.addCard(new gluttonmod.cards.Chrysosphagy());
/* 156 */     BaseMod.addCard(new gluttonmod.cards.Delusion());
/* 157 */     BaseMod.addCard(new Dispepsia());
/* 158 */     BaseMod.addCard(new gluttonmod.cards.GoldenArmor());
/* 159 */     BaseMod.addCard(new gluttonmod.cards.Migraine());
/* 160 */     BaseMod.addCard(new gluttonmod.cards.ObsessiveGreed());
/* 161 */     BaseMod.addCard(new ShareWeakness());
/* 162 */     BaseMod.addCard(new Toxicity());
/* 163 */     BaseMod.addCard(new gluttonmod.cards.Tumor());
/*     */     
/* 165 */     BaseMod.addCard(new gluttonmod.cards.FeverVisions());
/* 166 */     BaseMod.addCard(new gluttonmod.cards.Misery());
/* 167 */     BaseMod.addCard(new gluttonmod.cards.ToxicResidue());
/*     */     
/*     */ 
/*     */ 
/* 171 */     BaseMod.addCard(new Avarice());
/* 172 */     BaseMod.addCard(new gluttonmod.cards.Excrescence());
/* 173 */     BaseMod.addCard(new gluttonmod.cards.FragileMight());
/* 174 */     BaseMod.addCard(new gluttonmod.cards.Reminisce());
/* 175 */     BaseMod.addCard(new gluttonmod.cards.Retaliation());
/*     */     
/* 177 */     BaseMod.addCard(new gluttonmod.cards.Fast());
/* 178 */     BaseMod.addCard(new gluttonmod.cards.Hemophilia());
/* 179 */     BaseMod.addCard(new gluttonmod.cards.Inversion());
/* 180 */     BaseMod.addCard(new Malignancy());
/* 181 */     BaseMod.addCard(new gluttonmod.cards.Treasure());
/*     */     
/* 183 */     BaseMod.addCard(new Enfeeblement());
/* 184 */     BaseMod.addCard(new gluttonmod.cards.Megrim());
/* 185 */     BaseMod.addCard(new gluttonmod.cards.Nostalgia());
/* 186 */     BaseMod.addCard(new gluttonmod.cards.StarvationMode());
/*     */   }
/*     */   
/*     */   public void receiveEditStrings()
/*     */   {
/* 191 */     String relicStrings = com.badlogic.gdx.Gdx.files.internal("strings/relic-strings.json").readString(
/* 192 */       String.valueOf(java.nio.charset.StandardCharsets.UTF_8));
/* 193 */     BaseMod.loadCustomStrings(com.megacrit.cardcrawl.localization.RelicStrings.class, relicStrings);
/*     */   }
/*     */   
/*     */   public void receiveEditKeywords()
/*     */   {
/* 198 */     BaseMod.addKeyword("Hunger Pang", new String[] { "hunger pang", "hunger_pang", "hunger pangs", "hunger_pangs" }, "Hunger Pangs are unplayable status cards that damage you and draw you new cards.");
/*     */     
/* 200 */     BaseMod.addKeyword(new String[] { "echo", "echoes" }, "Echoes are copies of cards with ethereal and exhaust.");
/*     */     
/* 202 */     BaseMod.addKeyword(new String[] { "bleed" }, "Bleeding creatures lose HP at the start of their turn.");
/*     */     
/* 204 */     BaseMod.addKeyword(new String[] { "starving" }, "At the start of each turn, add Hunger Pangs to your discard pile.");
/*     */   }
/*     */   
/*     */ 
/*     */   public void receivePostDraw(AbstractCard c)
/*     */   {
/* 210 */     AbstractPlayer player = AbstractDungeon.player;
/*     */     
/* 212 */     for (AbstractPower p : player.powers) {
/* 213 */       if ((p instanceof AbstractGluttonPower)) {
/* 214 */         ((AbstractGluttonPower)p).onCardDraw(c);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void receiveOnBattleStart(AbstractRoom abstractRoom)
/*     */   {
/* 222 */     com.megacrit.cardcrawl.actions.GameActionManager.damageReceivedThisTurn = 0;
/*     */   }
/*     */   
/*     */   public static boolean hasDebuff(AbstractCreature c) {
/* 226 */     for (AbstractPower power : c.powers) {
/* 227 */       if (power.type == com.megacrit.cardcrawl.powers.AbstractPower.PowerType.DEBUFF) {
/* 228 */         return true;
/*     */       }
/*     */     }
/* 231 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\GluttonMod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */