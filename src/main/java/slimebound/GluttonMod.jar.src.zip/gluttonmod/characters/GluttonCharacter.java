/*     */ package gluttonmod.characters;
/*     */ 
/*     */ import basemod.abstracts.CustomPlayer;
/*     */ import com.badlogic.gdx.graphics.Color;
/*     */ import com.badlogic.gdx.graphics.g2d.BitmapFont;
/*     */ import com.badlogic.gdx.math.MathUtils;
/*     */ import com.esotericsoftware.spine.AnimationState;
/*     */ import com.esotericsoftware.spine.AnimationState.TrackEntry;
/*     */ import com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect;
/*     */ import com.megacrit.cardcrawl.audio.SoundMaster;
/*     */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*     */ import com.megacrit.cardcrawl.cards.AbstractCard.CardColor;
/*     */ import com.megacrit.cardcrawl.characters.AbstractPlayer.PlayerClass;
/*     */ import com.megacrit.cardcrawl.core.CardCrawlGame;
/*     */ import com.megacrit.cardcrawl.core.EnergyManager;
/*     */ import com.megacrit.cardcrawl.core.Settings;
/*     */ import com.megacrit.cardcrawl.helpers.FontHelper;
/*     */ import com.megacrit.cardcrawl.helpers.ScreenShake;
/*     */ import com.megacrit.cardcrawl.helpers.ScreenShake.ShakeDur;
/*     */ import com.megacrit.cardcrawl.helpers.ScreenShake.ShakeIntensity;
/*     */ import com.megacrit.cardcrawl.screens.CharSelectInfo;
/*     */ import com.megacrit.cardcrawl.unlock.UnlockTracker;
/*     */ import gluttonmod.GluttonMod;
/*     */ import gluttonmod.cards.Flail;
/*     */ import gluttonmod.patches.AbstractCardEnum;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ public class GluttonCharacter extends CustomPlayer
/*     */ {
/*     */   public static final int ENERGY_PER_TURN = 3;
/*     */   public static final String SHOULDER_2 = "char/shoulder2.png";
/*     */   public static final String SHOULDER_1 = "char/shoulder.png";
/*     */   public static final String CORPSE = "char/corpse.png";
/*     */   public static final String SKELETON_ATLAS = "char/skeleton.atlas";
/*     */   public static final String SKELETON_JSON = "char/skeleton.json";
/*  36 */   public static final String[] orbTextures = { "images/char/orb/layer1.png", "images/char/orb/layer2.png", "images/char/orb/layer3.png", "images/char/orb/layer4.png", "images/char/orb/layer5.png", "images/char/orb/layer6.png", "images/char/orb/layer1d.png", "images/char/orb/layer2d.png", "images/char/orb/layer3d.png", "images/char/orb/layer4d.png", "images/char/orb/layer5d.png" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GluttonCharacter(String name)
/*     */   {
/*  51 */     super(name, gluttonmod.patches.GluttonEnum.GLUTTON, orbTextures, "images/char/orb/vfx.png", (String)null, null);
/*     */     
/*     */ 
/*  54 */     this.dialogX = (this.drawX + 0.0F * Settings.scale);
/*  55 */     this.dialogY = (this.drawY + 220.0F * Settings.scale);
/*     */     
/*  57 */     initializeClass(null, GluttonMod.getResourcePath("char/shoulder2.png"), 
/*  58 */       GluttonMod.getResourcePath("char/shoulder.png"), 
/*  59 */       GluttonMod.getResourcePath("char/corpse.png"), 
/*  60 */       getLoadout(), 20.0F, -10.0F, 220.0F, 290.0F, new EnergyManager(3));
/*     */     
/*  62 */     loadAnimation(GluttonMod.getResourcePath("char/skeleton.atlas"), GluttonMod.getResourcePath("char/skeleton.json"), 1.0F);
/*  63 */     AnimationState.TrackEntry e = this.state.setAnimation(0, "animation", true);
/*  64 */     e.setTime(e.getEndTime() * MathUtils.random());
/*     */   }
/*     */   
/*     */   public ArrayList<String> getStartingDeck()
/*     */   {
/*  69 */     ArrayList<String> retVal = new ArrayList();
/*  70 */     retVal.add("Strike_Glutton");
/*  71 */     retVal.add("Strike_Glutton");
/*  72 */     retVal.add("Strike_Glutton");
/*  73 */     retVal.add("Strike_Glutton");
/*  74 */     retVal.add("Strike_Glutton");
/*  75 */     retVal.add("Strike_Glutton");
/*  76 */     retVal.add("Defend_Glutton");
/*  77 */     retVal.add("Defend_Glutton");
/*  78 */     retVal.add("Defend_Glutton");
/*  79 */     retVal.add("Flail");
/*  80 */     return retVal;
/*     */   }
/*     */   
/*     */   public ArrayList<String> getStartingRelics()
/*     */   {
/*  85 */     ArrayList<String> retVal = new ArrayList();
/*  86 */     retVal.add("EternalHunger");
/*  87 */     UnlockTracker.markRelicAsSeen("EternalHunger");
/*  88 */     return retVal;
/*     */   }
/*     */   
/*     */   public CharSelectInfo getLoadout()
/*     */   {
/*  93 */     return new CharSelectInfo("The Glutton", "A tormented being seeking to NL end its misery.", 120, 120, 0, 99, 5, this, 
/*     */     
/*  95 */       getStartingRelics(), getStartingDeck(), false);
/*     */   }
/*     */   
/*     */   public String getTitle(AbstractPlayer.PlayerClass playerClass)
/*     */   {
/* 100 */     return "The Glutton";
/*     */   }
/*     */   
/*     */   public AbstractCard.CardColor getCardColor()
/*     */   {
/* 105 */     return AbstractCardEnum.GLUTTON;
/*     */   }
/*     */   
/*     */   public Color getCardRenderColor()
/*     */   {
/* 110 */     return Color.LIME;
/*     */   }
/*     */   
/*     */   public AbstractCard getStartCardForEvent()
/*     */   {
/* 115 */     return new Flail();
/*     */   }
/*     */   
/*     */   public Color getCardTrailColor()
/*     */   {
/* 120 */     return Color.LIME.cpy();
/*     */   }
/*     */   
/*     */   public int getAscensionMaxHPLoss()
/*     */   {
/* 125 */     return 10;
/*     */   }
/*     */   
/*     */   public BitmapFont getEnergyNumFont()
/*     */   {
/* 130 */     return FontHelper.energyNumFontRed;
/*     */   }
/*     */   
/*     */   public void doCharSelectScreenSelectEffect()
/*     */   {
/* 135 */     CardCrawlGame.sound.playA("SLIME_SPLIT", MathUtils.random(-0.2F, 0.2F));
/* 136 */     CardCrawlGame.screenShake.shake(ScreenShake.ShakeIntensity.MED, ScreenShake.ShakeDur.SHORT, true);
/*     */   }
/*     */   
/*     */   public String getCustomModeCharacterButtonSoundKey()
/*     */   {
/* 141 */     return "SLIME_SPLIT";
/*     */   }
/*     */   
/*     */   public String getLocalizedCharacterName()
/*     */   {
/* 146 */     return "The Glutton";
/*     */   }
/*     */   
/*     */   public com.megacrit.cardcrawl.characters.AbstractPlayer newInstance()
/*     */   {
/* 151 */     return new GluttonCharacter(this.name);
/*     */   }
/*     */   
/*     */   public String getSpireHeartText()
/*     */   {
/* 156 */     return "NL You prepare to feast...";
/*     */   }
/*     */   
/*     */   public Color getSlashAttackColor()
/*     */   {
/* 161 */     return Color.RED;
/*     */   }
/*     */   
/*     */   public AbstractGameAction.AttackEffect[] getSpireHeartSlashEffect()
/*     */   {
/* 166 */     return new AbstractGameAction.AttackEffect[] { AbstractGameAction.AttackEffect.BLUNT_HEAVY, AbstractGameAction.AttackEffect.SMASH, AbstractGameAction.AttackEffect.BLUNT_HEAVY, AbstractGameAction.AttackEffect.SLASH_HEAVY, AbstractGameAction.AttackEffect.FIRE, AbstractGameAction.AttackEffect.BLUNT_HEAVY };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getVampireText()
/*     */   {
/* 174 */     return com.megacrit.cardcrawl.events.city.Vampires.DESCRIPTIONS[5];
/*     */   }
/*     */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\characters\GluttonCharacter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */