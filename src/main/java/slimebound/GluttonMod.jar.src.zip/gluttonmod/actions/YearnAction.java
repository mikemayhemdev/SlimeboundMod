/*    */ package gluttonmod.actions;
/*    */ 
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ 
/*    */ public class YearnAction extends com.megacrit.cardcrawl.actions.AbstractGameAction
/*    */ {
/*    */   private int echoAmount;
/*    */   
/*    */   public YearnAction(int echoAmount)
/*    */   {
/* 12 */     this.duration = 0.0F;
/* 13 */     this.actionType = com.megacrit.cardcrawl.actions.AbstractGameAction.ActionType.WAIT;
/* 14 */     this.echoAmount = echoAmount;
/*    */   }
/*    */   
/*    */   public void update()
/*    */   {
/* 19 */     if (AbstractDungeon.player.drawPile.isEmpty())
/*    */     {
/* 21 */       this.isDone = true;
/* 22 */       return;
/*    */     }
/* 24 */     AbstractCard card = AbstractDungeon.player.drawPile.getTopCard();
/* 25 */     if ((card.type != com.megacrit.cardcrawl.cards.AbstractCard.CardType.STATUS) && (card.type != com.megacrit.cardcrawl.cards.AbstractCard.CardType.CURSE))
/*    */     {
/* 27 */       AbstractDungeon.actionManager.addToBottom(new MakeEchoAction(card, this.echoAmount));
/*    */     }
/* 29 */     this.isDone = true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\actions\YearnAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */