/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.ApplyPowerAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import com.megacrit.cardcrawl.powers.VulnerablePower;
/*    */ import com.megacrit.cardcrawl.powers.WeakPower;
/*    */ 
/*    */ 
/*    */ public class Salivate
/*    */   extends AbstractGluttonCard
/*    */ {
/*    */   public static final int HP_LOSS_CHECK = 3;
/*    */   public static final String ID = "Salivate";
/*    */   public static final String NAME = "Salivate";
/*    */   public static final String DESCRIPTION = "Apply !M! Weak. If you have lost at least 3 HP this turn, also apply !M! Vulnerable.";
/*    */   public static final String IMG_PATH = "cards/salivate.png";
/* 24 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 25 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 26 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 2;
/*    */   private static final int UPGRADE_BONUS = 1;
/*    */   
/*    */   public Salivate()
/*    */   {
/* 34 */     super("Salivate", "Salivate", "cards/salivate.png", 1, "Apply !M! Weak. If you have lost at least 3 HP this turn, also apply !M! Vulnerable.", TYPE, RARITY, TARGET);
/*    */     
/* 36 */     this.baseMagicNumber = 2;
/* 37 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 42 */     AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(m, p, new WeakPower(m, this.magicNumber, false), this.magicNumber));
/*    */     
/* 44 */     if (GameActionManager.damageReceivedThisTurn >= 3) {
/* 45 */       AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(m, p, new VulnerablePower(m, this.magicNumber, false), this.magicNumber));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public AbstractCard makeCopy()
/*    */   {
/* 52 */     return new Salivate();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 57 */     if (!this.upgraded)
/*    */     {
/* 59 */       upgradeName();
/* 60 */       upgradeMagicNumber(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Salivate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */