/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Enfeeblement extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Enfeeblement";
/*    */   public static final String NAME = "Enfeeblement";
/*    */   public static final String DESCRIPTION = "Whenever you gain a debuff, deal !M! damage to a random enemy.";
/*    */   public static final String IMG_PATH = "cards/enfeeblement.png";
/* 17 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.POWER;
/* 18 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.RARE;
/* 19 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 4;
/*    */   private static final int UPGRADE_BONUS = 1;
/*    */   
/*    */   public Enfeeblement()
/*    */   {
/* 27 */     super("Enfeeblement", "Enfeeblement", "cards/enfeeblement.png", 1, "Whenever you gain a debuff, deal !M! damage to a random enemy.", TYPE, RARITY, TARGET);
/*    */     
/* 29 */     this.baseMagicNumber = 4;
/* 30 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 35 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.ApplyPowerAction(p, p, new gluttonmod.powers.EnfeeblementPower(p, this.magicNumber), this.magicNumber));
/*    */   }
/*    */   
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 41 */     return new Enfeeblement();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 46 */     if (!this.upgraded)
/*    */     {
/* 48 */       upgradeName();
/* 49 */       upgradeMagicNumber(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Enfeeblement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */