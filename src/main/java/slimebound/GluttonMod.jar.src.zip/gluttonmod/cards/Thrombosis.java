/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTags;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import gluttonmod.powers.ClotPower;
/*    */ 
/*    */ public class Thrombosis extends AbstractGluttonCard
/*    */ {
/*    */   private static final int PAIN = 3;
/*    */   private static final int HEAL = 3;
/*    */   public static final String ID = "Thrombosis";
/*    */   public static final String NAME = "Thrombosis";
/*    */   public static final String DESCRIPTION = "Lose 3 HP. NL Heal 3 HP a turn for the next !M! turns. NL Exhaust.";
/*    */   public static final String IMG_PATH = "cards/thrombosis.png";
/* 21 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 22 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 23 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 3;
/*    */   private static final int UPGRADE_MAGIC_BONUS = 1;
/*    */   
/*    */   public Thrombosis()
/*    */   {
/* 31 */     super("Thrombosis", "Thrombosis", "cards/thrombosis.png", 1, "Lose 3 HP. NL Heal 3 HP a turn for the next !M! turns. NL Exhaust.", TYPE, RARITY, TARGET);
/*    */     
/* 33 */     this.baseMagicNumber = 3;
/* 34 */     this.magicNumber = this.baseMagicNumber;
/* 35 */     this.tags.add(AbstractCard.CardTags.HEALING);
/* 36 */     this.exhaust = true;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 41 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.LoseHPAction(p, p, 3));
/* 42 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.ApplyPowerAction(p, p, new ClotPower(p, this.magicNumber), this.magicNumber));
/*    */   }
/*    */   
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 48 */     return new Thrombosis();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 53 */     if (!this.upgraded)
/*    */     {
/* 55 */       upgradeName();
/* 56 */       upgradeMagicNumber(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Thrombosis.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */