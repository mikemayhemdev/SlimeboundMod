/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class BellySlam extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "BellySlam";
/*    */   public static final String NAME = "Belly Slam";
/*    */   public static final String DESCRIPTION = "Deal damage equal to your HP divided by !M!.";
/*    */   public static final String EXTENDED_DESCRIPTION = " NL (Deals !D! damage.)";
/*    */   public static final String IMG_PATH = "cards/bellyslam.png";
/* 18 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 19 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 20 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 2;
/*    */   private static final int MAGIC = 4;
/*    */   private static final int POWER = 0;
/*    */   private static final int UPGRADE_BONUS = -1;
/*    */   
/*    */   public BellySlam()
/*    */   {
/* 29 */     super("BellySlam", "Belly Slam", "cards/bellyslam.png", 2, "Deal damage equal to your HP divided by !M!.", TYPE, RARITY, TARGET);
/*    */     
/* 31 */     this.baseMagicNumber = 4;
/* 32 */     this.baseDamage = 0;
/* 33 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 38 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(m, new com.megacrit.cardcrawl.cards.DamageInfo(p, this.damage, com.megacrit.cardcrawl.cards.DamageInfo.DamageType.NORMAL), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.SMASH));
/*    */     
/*    */ 
/* 41 */     this.rawDescription = "Deal damage equal to your HP divided by !M!.";
/* 42 */     initializeDescription();
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 47 */     return new BellySlam();
/*    */   }
/*    */   
/*    */   public void applyPowers()
/*    */   {
/* 52 */     this.baseDamage = (AbstractDungeon.player.currentHealth / this.magicNumber);
/* 53 */     super.applyPowers();
/* 54 */     this.rawDescription = "Deal damage equal to your HP divided by !M!. NL (Deals !D! damage.)";
/* 55 */     initializeDescription();
/*    */   }
/*    */   
/*    */   public void calculateCardDamage(AbstractMonster mo)
/*    */   {
/* 60 */     super.calculateCardDamage(mo);
/* 61 */     this.rawDescription = "Deal damage equal to your HP divided by !M!. NL (Deals !D! damage.)";
/* 62 */     initializeDescription();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 67 */     if (!this.upgraded)
/*    */     {
/* 69 */       upgradeName();
/* 70 */       upgradeMagicNumber(-1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\BellySlam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */