/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.cards.DamageInfo;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Devour extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Devour";
/*    */   public static final String NAME = "Devour";
/*    */   public static final String DESCRIPTION = "Exhaust a card. NL Deal !D! damage.";
/*    */   public static final String IMG_PATH = "cards/devour.png";
/* 18 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 19 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 20 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int POWER = 10;
/*    */   private static final int UPGRADE_BONUS = 5;
/*    */   
/*    */   public Devour()
/*    */   {
/* 28 */     super("Devour", "Devour", "cards/devour.png", 1, "Exhaust a card. NL Deal !D! damage.", TYPE, RARITY, TARGET);
/*    */     
/* 30 */     this.baseDamage = 10;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 35 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.ExhaustAction(p, p, 1, false));
/* 36 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.SLASH_HORIZONTAL));
/*    */   }
/*    */   
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 42 */     return new Devour();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 47 */     if (!this.upgraded)
/*    */     {
/* 49 */       upgradeName();
/* 50 */       upgradeDamage(5);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Devour.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */