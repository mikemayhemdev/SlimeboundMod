/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import basemod.helpers.BaseModCardTags;
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Defend_Glutton extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Defend_Glutton";
/*    */   public static final String NAME = "Defend";
/*    */   public static final String DESCRIPTION = "Gain !B! block.";
/*    */   public static final String IMG_PATH = "cards/defend.png";
/* 17 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 18 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.BASIC;
/* 19 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int BLOCK = 5;
/*    */   private static final int UPGRADE_BONUS = 3;
/*    */   
/*    */   public Defend_Glutton()
/*    */   {
/* 27 */     super("Defend_Glutton", "Defend", "cards/defend.png", 1, "Gain !B! block.", TYPE, RARITY, TARGET);
/*    */     
/* 29 */     this.baseBlock = 5;
/* 30 */     this.tags.add(BaseModCardTags.BASIC_DEFEND);
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 35 */     com.megacrit.cardcrawl.dungeons.AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.GainBlockAction(p, p, this.block));
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 40 */     return new Defend_Glutton();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 45 */     if (!this.upgraded)
/*    */     {
/* 47 */       upgradeName();
/* 48 */       upgradeBlock(3);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Defend_Glutton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */