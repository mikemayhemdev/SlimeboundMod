/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect;
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.DamageAction;
/*    */ import com.megacrit.cardcrawl.actions.common.GainBlockAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.cards.DamageInfo;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Throb extends AbstractGluttonCard
/*    */ {
/*    */   public static final int HP_LOSS_CHECK = 3;
/*    */   public static final String ID = "Throb";
/*    */   public static final String NAME = "Throb";
/*    */   public static final String DESCRIPTION = "Deal !D! damage. If you have lost at least 3 HP this turn, Gain !B! block.";
/*    */   public static final String IMG_PATH = "cards/throb.png";
/* 23 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 24 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 25 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int POWER = 7;
/*    */   private static final int BLOCK = 7;
/*    */   private static final int UPGRADE_BONUS = 3;
/*    */   
/*    */   public Throb()
/*    */   {
/* 34 */     super("Throb", "Throb", "cards/throb.png", 1, "Deal !D! damage. If you have lost at least 3 HP this turn, Gain !B! block.", TYPE, RARITY, TARGET);
/*    */     
/* 36 */     this.baseDamage = 7;
/* 37 */     this.baseBlock = 7;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 42 */     AbstractDungeon.actionManager.addToBottom(new DamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn), AbstractGameAction.AttackEffect.SLASH_VERTICAL));
/*    */     
/* 44 */     if (GameActionManager.damageReceivedThisTurn >= 3) {
/* 45 */       AbstractDungeon.actionManager.addToBottom(new GainBlockAction(p, p, this.block));
/*    */     }
/*    */   }
/*    */   
/*    */   public AbstractCard makeCopy()
/*    */   {
/* 51 */     return new Throb();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 56 */     if (!this.upgraded)
/*    */     {
/* 58 */       upgradeName();
/* 59 */       upgradeDamage(3);
/* 60 */       upgradeBlock(3);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Throb.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */