/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.ApplyPowerAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class ObsessiveGreed extends AbstractGluttonCard
/*    */ {
/*    */   private static final int PRICE = 30;
/*    */   public static final String ID = "ObsessiveGreed";
/*    */   public static final String NAME = "Obsessive Greed";
/*    */   public static final String DESCRIPTION = "Pay 30 Gold. NL Gain !M! Intangible.";
/*    */   public static final String CANT_PLAY = "I can't afford this card.";
/*    */   public static final String IMG_PATH = "cards/obsessivegreed.png";
/* 21 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 22 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 23 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 1;
/*    */   
/*    */   private static final int MAGIC = 1;
/*    */   private static final int UPGRADE_BONUS = 1;
/*    */   
/*    */   public ObsessiveGreed()
/*    */   {
/* 32 */     super("ObsessiveGreed", "Obsessive Greed", "cards/obsessivegreed.png", 1, "Pay 30 Gold. NL Gain !M! Intangible.", TYPE, RARITY, TARGET);
/*    */     
/* 34 */     this.baseMagicNumber = 1;
/* 35 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m) {
/* 39 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.unique.SpendGoldCombatAction(30));
/* 40 */     AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(p, p, new com.megacrit.cardcrawl.powers.IntangiblePlayerPower(p, this.magicNumber), this.magicNumber));
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean canUse(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 46 */     boolean canUse = super.canUse(p, m);
/* 47 */     if (!canUse) {
/* 48 */       return false;
/*    */     }
/* 50 */     if (p.gold < 30) {
/* 51 */       this.cantUseMessage = "I can't afford this card.";
/* 52 */       return false;
/*    */     }
/* 54 */     return true;
/*    */   }
/*    */   
/*    */   public AbstractCard makeCopy()
/*    */   {
/* 59 */     return new ObsessiveGreed();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 64 */     if (!this.upgraded)
/*    */     {
/* 66 */       upgradeName();
/* 67 */       upgradeMagicNumber(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\ObsessiveGreed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */