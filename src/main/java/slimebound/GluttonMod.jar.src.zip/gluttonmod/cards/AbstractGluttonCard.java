/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import basemod.abstracts.CustomCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ 
/*    */ public abstract class AbstractGluttonCard extends CustomCard
/*    */ {
/*    */   public AbstractGluttonCard(String id, String name, String img, int cost, String rawDescription, com.megacrit.cardcrawl.cards.AbstractCard.CardType type, AbstractCard.CardRarity rarity, com.megacrit.cardcrawl.cards.AbstractCard.CardTarget target)
/*    */   {
/* 10 */     super(id, name, gluttonmod.GluttonMod.getResourcePath(img), cost, rawDescription, type, gluttonmod.patches.AbstractCardEnum.GLUTTON, rarity, target);
/*    */   }
/*    */   
/*    */   public void onChangeGold(int amount) {}
/*    */   
/*    */   public void onLoseGoldFromCard(int gold) {}
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\AbstractGluttonCard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */