/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.DamageAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.cards.DamageInfo;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Profligacy extends AbstractGluttonCard
/*    */ {
/*    */   private static final int PRICE = 10;
/*    */   public static final String ID = "Profligacy";
/*    */   public static final String NAME = "Profligacy";
/*    */   public static final String DESCRIPTION = "Pay 10 Gold. NL Deal !D! damage.";
/*    */   public static final String CANT_PLAY = "I can't afford this card.";
/*    */   public static final String IMG_PATH = "cards/profligacy.png";
/* 22 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 23 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 24 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 2;
/*    */   private static final int POWER = 20;
/*    */   private static final int UPGRADE_BONUS = 8;
/*    */   
/*    */   public Profligacy()
/*    */   {
/* 32 */     super("Profligacy", "Profligacy", "cards/profligacy.png", 2, "Pay 10 Gold. NL Deal !D! damage.", TYPE, RARITY, TARGET);
/*    */     
/* 34 */     this.baseDamage = 20;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 39 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.unique.SpendGoldCombatAction(10));
/* 40 */     AbstractDungeon.actionManager.addToBottom(new DamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.SLASH_HEAVY));
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean canUse(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 46 */     boolean canUse = super.canUse(p, m);
/* 47 */     if (!canUse) {
/* 48 */       return false;
/*    */     }
/* 50 */     if (p.gold < 10) {
/* 51 */       this.cantUseMessage = "I can't afford this card.";
/* 52 */       return false;
/*    */     }
/* 54 */     return true;
/*    */   }
/*    */   
/*    */   public AbstractCard makeCopy()
/*    */   {
/* 59 */     return new Profligacy();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 64 */     if (!this.upgraded)
/*    */     {
/* 66 */       upgradeName();
/* 67 */       upgradeDamage(8);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Profligacy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */