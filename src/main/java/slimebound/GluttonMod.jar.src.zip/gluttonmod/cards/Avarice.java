/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.animations.VFXAction;
/*    */ import com.megacrit.cardcrawl.actions.utility.WaitAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.cards.DamageInfo;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.helpers.Hitbox;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import com.megacrit.cardcrawl.vfx.combat.WeightyImpactEffect;
/*    */ 
/*    */ public class Avarice extends AbstractGluttonCard
/*    */ {
/*    */   public static final int PRICE = 100;
/*    */   public static final String ID = "Avarice";
/*    */   public static final String NAME = "Avarice";
/*    */   public static final String DESCRIPTION = "Costs 1 less [R]  for every 100 gold you have. NL Deal !D! damage.";
/*    */   public static final String IMG_PATH = "cards/avarice.png";
/* 24 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 25 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.RARE;
/* 26 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 5;
/*    */   private static final int POWER = 30;
/*    */   private static final int UPGRADE_BONUS = 10;
/*    */   
/*    */   public Avarice()
/*    */   {
/* 34 */     super("Avarice", "Avarice", "cards/avarice.png", 5, "Costs 1 less [R]  for every 100 gold you have. NL Deal !D! damage.", TYPE, RARITY, TARGET);
/*    */     
/* 36 */     this.baseDamage = 30;
/*    */   }
/*    */   
/*    */   public void updateCostAlt(int amt) {
/* 40 */     int tmpCost = this.cost;
/* 41 */     int diff = this.cost - this.costForTurn;
/*    */     
/* 43 */     tmpCost += amt;
/* 44 */     if (tmpCost < 0) {
/* 45 */       tmpCost = 0;
/*    */     }
/* 47 */     if (tmpCost != this.cost)
/*    */     {
/* 49 */       this.cost = tmpCost;
/* 50 */       this.costForTurn = (this.cost - diff);
/* 51 */       if (this.costForTurn < 0) {
/* 52 */         this.costForTurn = 0;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void triggerWhenDrawn() {
/* 58 */     if ((!this.isCostModified) && (!this.isCostModifiedForTurn)) {
/* 59 */       int current = this.cost;
/* 60 */       int desired = 5 - AbstractDungeon.player.gold / 100;
/* 61 */       updateCostAlt(desired - current);
/*    */     }
/*    */   }
/*    */   
/*    */   public void onChangeGold(int amount) {
/* 66 */     if ((!this.isCostModified) && (!this.isCostModifiedForTurn)) {
/* 67 */       int current = this.cost;
/* 68 */       int desired = 5 - AbstractDungeon.player.gold / 100;
/* 69 */       updateCostAlt(desired - current);
/*    */     }
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 75 */     if (m != null) {
/* 76 */       AbstractDungeon.actionManager.addToBottom(new VFXAction(new WeightyImpactEffect(m.hb.cX, m.hb.cY)));
/*    */     }
/* 78 */     AbstractDungeon.actionManager.addToBottom(new WaitAction(0.8F));
/* 79 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.NONE));
/*    */   }
/*    */   
/*    */ 
/*    */   public AbstractCard makeCopy()
/*    */   {
/* 85 */     AbstractCard tmp = new Avarice();
/* 86 */     if (AbstractDungeon.player != null) {
/* 87 */       ((Avarice)tmp).updateCostAlt(-(AbstractDungeon.player.gold / 100));
/*    */     }
/* 89 */     return tmp;
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 94 */     if (!this.upgraded)
/*    */     {
/* 96 */       upgradeName();
/* 97 */       upgradeDamage(10);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Avarice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */