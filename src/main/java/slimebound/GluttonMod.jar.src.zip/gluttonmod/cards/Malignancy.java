/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.evacipated.cardcrawl.mod.stslib.fields.cards.AbstractCard.AlwaysRetainField;
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Malignancy extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Malignancy";
/*    */   public static final String NAME = "Malignancy";
/*    */   public static final String DESCRIPTION = "Unplayable. NL If this card is exhausted, gain !M! Intangible.";
/*    */   public static final String UPGRADE_DESCRIPTION = "Unplayable. NL Retain. NL If this card is exhausted, gain !M! Intangible.";
/*    */   public static final String CANT_PLAY = "I can't play this card.";
/*    */   public static final String IMG_PATH = "cards/malignancy.png";
/* 20 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 21 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.RARE;
/* 22 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.NONE;
/*    */   
/*    */   private static final int COST = -2;
/*    */   private static final int MAGIC = 2;
/*    */   
/*    */   public Malignancy()
/*    */   {
/* 29 */     super("Malignancy", "Malignancy", "cards/malignancy.png", -2, "Unplayable. NL If this card is exhausted, gain !M! Intangible.", TYPE, RARITY, TARGET);
/* 30 */     this.baseMagicNumber = 2;
/* 31 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m) {}
/*    */   
/*    */   public boolean canUse(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 38 */     this.cantUseMessage = "I can't play this card.";
/* 39 */     return false;
/*    */   }
/*    */   
/*    */   public void triggerOnExhaust() {
/* 43 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.ApplyPowerAction(AbstractDungeon.player, AbstractDungeon.player, new com.megacrit.cardcrawl.powers.IntangiblePlayerPower(AbstractDungeon.player, this.magicNumber), this.magicNumber));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 50 */     return new Malignancy();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 55 */     if (!this.upgraded)
/*    */     {
/* 57 */       upgradeName();
/* 58 */       AlwaysRetainField.alwaysRetain.set(this, Boolean.valueOf(true));
/* 59 */       this.retain = true;
/* 60 */       this.rawDescription = "Unplayable. NL Retain. NL If this card is exhausted, gain !M! Intangible.";
/* 61 */       initializeDescription();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Malignancy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */