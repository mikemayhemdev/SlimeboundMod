/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.ApplyPowerAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.cards.DamageInfo;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import com.megacrit.cardcrawl.powers.ThornsPower;
/*    */ 
/*    */ public class BloodyKnuckle extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "BloodyKnuckle";
/*    */   public static final String NAME = "Bloody Knuckle";
/*    */   public static final String DESCRIPTION = "Give an enemy Thorns. Deal !D! damage !M! times.";
/*    */   public static final String IMG_PATH = "cards/bloodyknuckle.png";
/* 21 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 22 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 23 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 3;
/*    */   private static final int POWER = 6;
/*    */   private static final int UPGRADE_BONUS = 2;
/*    */   
/*    */   public BloodyKnuckle()
/*    */   {
/* 32 */     super("BloodyKnuckle", "Bloody Knuckle", "cards/bloodyknuckle.png", 1, "Give an enemy Thorns. Deal !D! damage !M! times.", TYPE, RARITY, TARGET);
/*    */     
/* 34 */     this.baseMagicNumber = 3;
/* 35 */     this.baseDamage = 6;
/* 36 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 41 */     AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(m, p, new ThornsPower(m, 1), 1));
/*    */     
/* 43 */     for (int i = 0; i < this.magicNumber - 1; i++) {
/* 44 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.PummelDamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn)));
/*    */     }
/*    */     
/* 47 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.BLUNT_HEAVY));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public AbstractCard makeCopy()
/*    */   {
/* 54 */     return new BloodyKnuckle();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 59 */     if (!this.upgraded)
/*    */     {
/* 61 */       upgradeName();
/* 62 */       upgradeDamage(2);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\BloodyKnuckle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */