/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import gluttonmod.powers.MiseryPower;
/*    */ 
/*    */ public class Misery extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Misery";
/*    */   public static final String NAME = "Misery";
/*    */   public static final String DESCRIPTION = "Whenever you lose HP, deal !M! damage to ALL enemies.";
/*    */   public static final String IMG_PATH = "cards/misery.png";
/* 17 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.POWER;
/* 18 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 19 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 2;
/*    */   private static final int MAGIC = 2;
/*    */   private static final int UPGRADE_BONUS = 1;
/*    */   
/*    */   public Misery()
/*    */   {
/* 27 */     super("Misery", "Misery", "cards/misery.png", 2, "Whenever you lose HP, deal !M! damage to ALL enemies.", TYPE, RARITY, TARGET);
/*    */     
/* 29 */     this.baseMagicNumber = 2;
/* 30 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 35 */     com.megacrit.cardcrawl.dungeons.AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.ApplyPowerAction(p, p, new MiseryPower(p, this.magicNumber), this.magicNumber));
/*    */   }
/*    */   
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 41 */     return new Misery();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 46 */     if (!this.upgraded)
/*    */     {
/* 48 */       upgradeName();
/* 49 */       upgradeMagicNumber(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Misery.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */