/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class GoldenArmor extends AbstractGluttonCard
/*    */ {
/*    */   public static final int EXCHANGE = 15;
/*    */   public static final String ID = "GoldenArmor";
/*    */   public static final String NAME = "Golden Armor";
/*    */   public static final String DESCRIPTION = "Gain 1 Block for every 15 gold you have.";
/*    */   public static final String EXTENDED_DESCRIPTION = " NL (Gain !B! block.)";
/*    */   public static final String IMG_PATH = "cards/goldenarmor.png";
/* 18 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 19 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 20 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 2;
/*    */   private static final int BLOCK = 0;
/*    */   private static final int UPGRADE_COST = 1;
/*    */   
/*    */   public GoldenArmor()
/*    */   {
/* 28 */     super("GoldenArmor", "Golden Armor", "cards/goldenarmor.png", 2, "Gain 1 Block for every 15 gold you have.", TYPE, RARITY, TARGET);
/*    */     
/* 30 */     this.baseBlock = 0;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 35 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.GainBlockAction(p, p, this.block));
/* 36 */     this.rawDescription = "Gain 1 Block for every 15 gold you have.";
/* 37 */     initializeDescription();
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 42 */     return new GoldenArmor();
/*    */   }
/*    */   
/*    */   public void applyPowers()
/*    */   {
/* 47 */     this.baseBlock = (AbstractDungeon.player.gold / 15);
/* 48 */     super.applyPowers();
/* 49 */     this.rawDescription = "Gain 1 Block for every 15 gold you have. NL (Gain !B! block.)";
/* 50 */     initializeDescription();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 55 */     if (!this.upgraded)
/*    */     {
/* 57 */       upgradeName();
/* 58 */       upgradeBaseCost(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\GoldenArmor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */