/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.DamageAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.cards.DamageInfo;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import gluttonmod.actions.GnawingHungerAction;
/*    */ 
/*    */ public class GnawingHunger extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "GnawingHunger";
/*    */   public static final String NAME = "Gnawing Hunger";
/*    */   public static final String DESCRIPTION = "Lose !M! HP. Deal !D! damage. When played, permanently increase the damage by 2 and HP loss by 1. Exhaust.";
/*    */   public static final String UPGRADED_DESCRIPTION = "Lose !M! HP. Deal !D! damage. When played, permanently increase the damage by 2 and HP loss by 1.";
/*    */   public static final String IMG_PATH = "cards/gnawinghunger.png";
/* 22 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 23 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 24 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MORE_DAMAGE = 1;
/*    */   private static final int INITIAL_MAGIC = 1;
/*    */   private static final int INCREASE = 1;
/*    */   
/*    */   public GnawingHunger()
/*    */   {
/* 33 */     super("GnawingHunger", "Gnawing Hunger", "cards/gnawinghunger.png", 1, "Lose !M! HP. Deal !D! damage. When played, permanently increase the damage by 2 and HP loss by 1. Exhaust.", TYPE, RARITY, TARGET);
/*    */     
/* 35 */     this.misc = 1;
/* 36 */     this.baseMagicNumber = this.misc;
/* 37 */     this.baseDamage = (this.misc * 2 + 1);
/* 38 */     this.magicNumber = this.baseMagicNumber;
/*    */     
/* 40 */     this.exhaust = true;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 45 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.LoseHPAction(p, p, this.magicNumber));
/* 46 */     AbstractDungeon.actionManager.addToBottom(new DamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.SMASH));
/*    */     
/* 48 */     AbstractDungeon.actionManager.addToBottom(new GnawingHungerAction(this.uuid, 1, 1));
/*    */   }
/*    */   
/*    */   public AbstractCard makeCopy()
/*    */   {
/* 53 */     return new GnawingHunger();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 58 */     if (!this.upgraded)
/*    */     {
/* 60 */       upgradeName();
/* 61 */       if (!this.isEthereal)
/* 62 */         this.exhaust = false;
/* 63 */       this.rawDescription = "Lose !M! HP. Deal !D! damage. When played, permanently increase the damage by 2 and HP loss by 1.";
/* 64 */       initializeDescription();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\GnawingHunger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */