/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.MakeTempCardInDiscardAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Voracity extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Voracity";
/*    */   public static final String NAME = "Voracity";
/*    */   public static final String DESCRIPTION = "Deal !D! damage. Shuffle a Hunger_Pang into your discard pile.";
/*    */   public static final String IMG_PATH = "cards/voracity.png";
/* 18 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 19 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 20 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int POWER = 12;
/*    */   private static final int UPGRADE_BONUS = 5;
/*    */   
/*    */   public Voracity()
/*    */   {
/* 28 */     super("Voracity", "Voracity", "cards/voracity.png", 1, "Deal !D! damage. Shuffle a Hunger_Pang into your discard pile.", TYPE, RARITY, TARGET);
/*    */     
/* 30 */     this.baseDamage = 12;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 35 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(m, new com.megacrit.cardcrawl.cards.DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.SLASH_HEAVY));
/*    */     
/*    */ 
/* 38 */     AbstractDungeon.actionManager.addToBottom(new MakeTempCardInDiscardAction(new HungerPang(), 1));
/*    */   }
/*    */   
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 44 */     return new Voracity();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 49 */     if (!this.upgraded)
/*    */     {
/* 51 */       upgradeName();
/* 52 */       upgradeDamage(5);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Voracity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */