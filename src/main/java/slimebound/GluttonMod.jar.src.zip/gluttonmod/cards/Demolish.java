/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect;
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.DamageAllEnemiesAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Demolish extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Demolish";
/*    */   public static final String NAME = "Demolish";
/*    */   public static final String DESCRIPTION = "Deal !D! damage to ALL enemies. NL If this card is Exhausted, deal !D! damage to ALL enemies three times.";
/*    */   public static final String IMG_PATH = "cards/demolish.png";
/* 16 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 17 */   private static final com.megacrit.cardcrawl.cards.AbstractCard.CardRarity RARITY = com.megacrit.cardcrawl.cards.AbstractCard.CardRarity.COMMON;
/* 18 */   private static final com.megacrit.cardcrawl.cards.AbstractCard.CardTarget TARGET = com.megacrit.cardcrawl.cards.AbstractCard.CardTarget.ALL_ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int POWER = 4;
/*    */   private static final int UPGRADE_BONUS = 2;
/*    */   
/*    */   public Demolish()
/*    */   {
/* 26 */     super("Demolish", "Demolish", "cards/demolish.png", 1, "Deal !D! damage to ALL enemies. NL If this card is Exhausted, deal !D! damage to ALL enemies three times.", TYPE, RARITY, TARGET);
/*    */     
/* 28 */     this.baseDamage = 4;
/* 29 */     this.isMultiDamage = true;
/*    */   }
/*    */   
/*    */   public void use(com.megacrit.cardcrawl.characters.AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 34 */     AbstractDungeon.actionManager.addToBottom(new DamageAllEnemiesAction(p, this.multiDamage, this.damageTypeForTurn, AbstractGameAction.AttackEffect.SLASH_HORIZONTAL));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void triggerOnExhaust()
/*    */   {
/* 41 */     AbstractDungeon.actionManager.addToBottom(new DamageAllEnemiesAction(AbstractDungeon.player, this.multiDamage, this.damageTypeForTurn, AbstractGameAction.AttackEffect.SLASH_HORIZONTAL));
/*    */     
/*    */ 
/* 44 */     AbstractDungeon.actionManager.addToBottom(new DamageAllEnemiesAction(AbstractDungeon.player, this.multiDamage, this.damageTypeForTurn, AbstractGameAction.AttackEffect.SLASH_VERTICAL));
/*    */     
/*    */ 
/* 47 */     AbstractDungeon.actionManager.addToBottom(new DamageAllEnemiesAction(AbstractDungeon.player, this.multiDamage, this.damageTypeForTurn, AbstractGameAction.AttackEffect.SLASH_DIAGONAL));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 54 */     return new Demolish();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 59 */     if (!this.upgraded)
/*    */     {
/* 61 */       upgradeName();
/* 62 */       upgradeDamage(2);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Demolish.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */