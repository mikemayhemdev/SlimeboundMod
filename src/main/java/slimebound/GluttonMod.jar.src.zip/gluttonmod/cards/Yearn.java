/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Yearn extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Yearn";
/*    */   public static final String NAME = "Yearn";
/*    */   public static final String DESCRIPTION = "Draw a card. If it is not a status or curse, create an echo of it. NL Exhaust.";
/*    */   public static final String UPGRADED_DESCRIPTION = "Draw a card. If it is not a status or curse, create an echo of it.";
/*    */   public static final String IMG_PATH = "cards/yearn.png";
/* 18 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 19 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 20 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 0;
/*    */   private static final int MAGIC = 1;
/*    */   
/*    */   public Yearn()
/*    */   {
/* 27 */     super("Yearn", "Yearn", "cards/yearn.png", 0, "Draw a card. If it is not a status or curse, create an echo of it. NL Exhaust.", TYPE, RARITY, TARGET);
/*    */     
/* 29 */     this.baseMagicNumber = 1;
/* 30 */     this.magicNumber = this.baseMagicNumber;
/* 31 */     this.tags.add(com.megacrit.cardcrawl.cards.AbstractCard.CardTags.HEALING);
/* 32 */     this.exhaust = true;
/*    */   }
/*    */   
/*    */ 
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 38 */     AbstractDungeon.actionManager.addToBottom(new gluttonmod.actions.YearnAction(this.magicNumber));
/* 39 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DrawCardAction(AbstractDungeon.player, 1));
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 44 */     return new Yearn();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 49 */     if (!this.upgraded)
/*    */     {
/* 51 */       upgradeName();
/* 52 */       if (!this.isEthereal)
/* 53 */         this.exhaust = false;
/* 54 */       this.rawDescription = "Draw a card. If it is not a status or curse, create an echo of it.";
/* 55 */       initializeDescription();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Yearn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */