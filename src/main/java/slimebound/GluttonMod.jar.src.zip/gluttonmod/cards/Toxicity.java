/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.ApplyPowerAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Toxicity extends AbstractGluttonCard
/*    */ {
/*    */   private static final int DRAWBACK = 2;
/*    */   public static final String ID = "Toxicity";
/*    */   public static final String NAME = "Toxicity";
/*    */   public static final String DESCRIPTION = "Gain 2 Weak, Frail, and Vulnerable. NL Apply !M! Poison.";
/*    */   public static final String IMG_PATH = "cards/toxicity.png";
/* 19 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 20 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 21 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 8;
/*    */   private static final int UPGRADE_MAGIC_BONUS = 3;
/*    */   
/*    */   public Toxicity()
/*    */   {
/* 29 */     super("Toxicity", "Toxicity", "cards/toxicity.png", 1, "Gain 2 Weak, Frail, and Vulnerable. NL Apply !M! Poison.", TYPE, RARITY, TARGET);
/*    */     
/* 31 */     this.baseMagicNumber = 8;
/* 32 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 37 */     AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(p, p, new com.megacrit.cardcrawl.powers.WeakPower(p, 2, false), 2));
/*    */     
/* 39 */     AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(p, p, new com.megacrit.cardcrawl.powers.FrailPower(p, 2, false), 2));
/*    */     
/* 41 */     AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(p, p, new com.megacrit.cardcrawl.powers.VulnerablePower(p, 2, false), 2));
/*    */     
/*    */ 
/* 44 */     AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(m, p, new com.megacrit.cardcrawl.powers.PoisonPower(m, p, this.magicNumber), this.magicNumber, com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.POISON));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 51 */     return new Toxicity();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 56 */     if (!this.upgraded)
/*    */     {
/* 58 */       upgradeName();
/* 59 */       upgradeMagicNumber(3);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Toxicity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */