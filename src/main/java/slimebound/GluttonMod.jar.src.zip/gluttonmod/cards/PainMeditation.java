/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.DrawCardAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class PainMeditation extends AbstractGluttonCard
/*    */ {
/*    */   public static final int HP_LOSS_CHECK = 3;
/*    */   public static final String ID = "PainMeditation";
/*    */   public static final String NAME = "Pain Meditation";
/*    */   public static final String DESCRIPTION = "Draw a card. If you have lost at least 3 HP this turn, draw another card.";
/*    */   public static final String IMG_PATH = "cards/painmeditation.png";
/* 20 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 21 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 22 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int UPGRADE_COST = 0;
/*    */   
/*    */   public PainMeditation()
/*    */   {
/* 29 */     super("PainMeditation", "Pain Meditation", "cards/painmeditation.png", 1, "Draw a card. If you have lost at least 3 HP this turn, draw another card.", TYPE, RARITY, TARGET);
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 34 */     AbstractDungeon.actionManager.addToTop(new DrawCardAction(AbstractDungeon.player, 1));
/* 35 */     if (GameActionManager.damageReceivedThisTurn >= 3) {
/* 36 */       AbstractDungeon.actionManager.addToTop(new DrawCardAction(AbstractDungeon.player, 1));
/*    */     }
/*    */   }
/*    */   
/*    */   public AbstractCard makeCopy()
/*    */   {
/* 42 */     return new PainMeditation();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 47 */     if (!this.upgraded)
/*    */     {
/* 49 */       upgradeName();
/* 50 */       upgradeBaseCost(0);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\PainMeditation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */