/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.ApplyPowerAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class StarvationMode extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "StarvationMode";
/*    */   public static final String NAME = "Starvation Mode";
/*    */   public static final String DESCRIPTION = "Gain Starving. NL Whenever you draw a status or curse, apply !M! Poison to ALL enemies.";
/*    */   public static final String IMG_PATH = "cards/starvationmode.png";
/* 18 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.POWER;
/* 19 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.RARE;
/* 20 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 2;
/*    */   private static final int MAGIC = 3;
/*    */   private static final int UPGRADE_BONUS = 1;
/*    */   
/*    */   public StarvationMode()
/*    */   {
/* 28 */     super("StarvationMode", "Starvation Mode", "cards/starvationmode.png", 2, "Gain Starving. NL Whenever you draw a status or curse, apply !M! Poison to ALL enemies.", TYPE, RARITY, TARGET);
/*    */     
/* 30 */     this.baseMagicNumber = 3;
/* 31 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 36 */     AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(p, p, new gluttonmod.powers.StarvingPower(p, 1), 1));
/*    */     
/* 38 */     AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(p, p, new gluttonmod.powers.StarvationModePower(p, this.magicNumber), this.magicNumber));
/*    */   }
/*    */   
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 44 */     return new StarvationMode();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 49 */     if (!this.upgraded)
/*    */     {
/* 51 */       upgradeName();
/* 52 */       upgradeMagicNumber(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\StarvationMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */