/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.helpers.Hitbox;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class Mug extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Mug";
/*    */   public static final String NAME = "Mug";
/*    */   public static final String DESCRIPTION = "Deal !D! damage. NL Gain !M! Gold. Exhaust.";
/*    */   public static final String IMG_PATH = "cards/mug.png";
/* 19 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 20 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 21 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 15;
/*    */   private static final int POWER = 10;
/*    */   private static final int UPGRADE_MAGIC_BONUS = 5;
/*    */   private static final int UPGRADE_POWER_BONUS = 2;
/*    */   
/*    */   public Mug()
/*    */   {
/* 31 */     super("Mug", "Mug", "cards/mug.png", 1, "Deal !D! damage. NL Gain !M! Gold. Exhaust.", TYPE, RARITY, TARGET);
/*    */     
/* 33 */     this.baseMagicNumber = 15;
/* 34 */     this.baseDamage = 10;
/* 35 */     this.magicNumber = this.baseMagicNumber;
/* 36 */     this.exhaust = true;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 41 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(m, new com.megacrit.cardcrawl.cards.DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.SLASH_HORIZONTAL));
/*    */     
/* 43 */     p.gainGold(this.magicNumber);
/* 44 */     for (int i = 0; i < this.magicNumber; i++) {
/* 45 */       AbstractDungeon.effectList.add(new com.megacrit.cardcrawl.vfx.GainPennyEffect(p, m.hb.cX, m.hb.cY, p.hb.cX, p.hb.cY, true));
/*    */     }
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 51 */     return new Mug();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 56 */     if (!this.upgraded)
/*    */     {
/* 58 */       upgradeName();
/* 59 */       upgradeDamage(2);
/* 60 */       upgradeMagicNumber(5);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Mug.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */