/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import gluttonmod.actions.DelusionAction;
/*    */ 
/*    */ public class Delusion extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Delusion";
/*    */   public static final String NAME = "Delusion";
/*    */   public static final String DESCRIPTION = "Create an echo of a non-ethereal card in your hand. NL Exhaust.";
/*    */   public static final String UPGRADED_DESCRIPTION = "Create two echoes of a non-ethereal card in your hand. NL Exhaust.";
/*    */   public static final String IMG_PATH = "cards/delusion.png";
/* 17 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 18 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 19 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 0;
/*    */   private static final int MAGIC = 1;
/*    */   private static final int UPGRADE_MAGIC_BONUS = 1;
/*    */   
/*    */   public Delusion()
/*    */   {
/* 27 */     super("Delusion", "Delusion", "cards/delusion.png", 0, "Create an echo of a non-ethereal card in your hand. NL Exhaust.", TYPE, RARITY, TARGET);
/*    */     
/* 29 */     this.baseMagicNumber = 1;
/* 30 */     this.magicNumber = this.baseMagicNumber;
/* 31 */     this.tags.add(com.megacrit.cardcrawl.cards.AbstractCard.CardTags.HEALING);
/* 32 */     this.exhaust = true;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 37 */     com.megacrit.cardcrawl.dungeons.AbstractDungeon.actionManager.addToBottom(new DelusionAction(p, this.magicNumber));
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 42 */     return new Delusion();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 47 */     if (!this.upgraded)
/*    */     {
/* 49 */       upgradeName();
/* 50 */       upgradeMagicNumber(1);
/* 51 */       this.rawDescription = "Create two echoes of a non-ethereal card in your hand. NL Exhaust.";
/* 52 */       initializeDescription();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Delusion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */