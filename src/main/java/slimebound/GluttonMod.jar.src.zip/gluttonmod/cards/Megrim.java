/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Megrim extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Megrim";
/*    */   public static final String NAME = "Megrim";
/*    */   public static final String DESCRIPTION = "Whenever you draw a card, deal !M! damage to a random enemy.";
/*    */   public static final String IMG_PATH = "cards/megrim.png";
/* 17 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.POWER;
/* 18 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.RARE;
/* 19 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 3;
/*    */   private static final int MAGIC = 1;
/*    */   private static final int UPGRADE_BONUS = 1;
/*    */   
/*    */   public Megrim()
/*    */   {
/* 27 */     super("Megrim", "Megrim", "cards/megrim.png", 3, "Whenever you draw a card, deal !M! damage to a random enemy.", TYPE, RARITY, TARGET);
/*    */     
/* 29 */     this.baseMagicNumber = 1;
/* 30 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 35 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.ApplyPowerAction(p, p, new gluttonmod.powers.MegrimPower(p, this.magicNumber), this.magicNumber));
/*    */   }
/*    */   
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 41 */     return new Megrim();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 46 */     if (!this.upgraded)
/*    */     {
/* 48 */       upgradeName();
/* 49 */       upgradeMagicNumber(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Megrim.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */