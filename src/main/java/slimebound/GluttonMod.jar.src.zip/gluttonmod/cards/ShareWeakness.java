/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.ApplyPowerAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import com.megacrit.cardcrawl.monsters.MonsterGroup;
/*    */ 
/*    */ public class ShareWeakness extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "ShareWeakness";
/*    */   public static final String NAME = "Share Weakness";
/*    */   public static final String DESCRIPTION = "If you are Weak, apply !M! Weak to ALL enemies. NL Repeat for Frail and Vulnerable.";
/*    */   public static final String IMG_PATH = "cards/shareweakness.png";
/* 17 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 18 */   private static final com.megacrit.cardcrawl.cards.AbstractCard.CardRarity RARITY = com.megacrit.cardcrawl.cards.AbstractCard.CardRarity.UNCOMMON;
/* 19 */   private static final com.megacrit.cardcrawl.cards.AbstractCard.CardTarget TARGET = com.megacrit.cardcrawl.cards.AbstractCard.CardTarget.ALL_ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 2;
/*    */   private static final int UPGRADE_MAGIC_BONUS = 1;
/*    */   
/*    */   public ShareWeakness()
/*    */   {
/* 27 */     super("ShareWeakness", "Share Weakness", "cards/shareweakness.png", 1, "If you are Weak, apply !M! Weak to ALL enemies. NL Repeat for Frail and Vulnerable.", TYPE, RARITY, TARGET);
/*    */     
/* 29 */     this.baseMagicNumber = 2;
/* 30 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 35 */     if (!AbstractDungeon.getMonsters().areMonstersBasicallyDead())
/*    */     {
/* 37 */       if (p.hasPower("Weakened")) {
/* 38 */         flash();
/* 39 */         for (AbstractMonster monster : AbstractDungeon.getMonsters().monsters) {
/* 40 */           if ((!monster.isDead) && (!monster.isDying))
/*    */           {
/* 42 */             AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(monster, p, new com.megacrit.cardcrawl.powers.WeakPower(monster, this.magicNumber, false), this.magicNumber));
/*    */           }
/*    */         }
/*    */       }
/*    */       
/*    */ 
/* 48 */       if (p.hasPower("Frail")) {
/* 49 */         flash();
/* 50 */         for (AbstractMonster monster : AbstractDungeon.getMonsters().monsters) {
/* 51 */           if ((!monster.isDead) && (!monster.isDying))
/*    */           {
/* 53 */             AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(monster, p, new com.megacrit.cardcrawl.powers.FrailPower(monster, this.magicNumber, false), this.magicNumber));
/*    */           }
/*    */         }
/*    */       }
/*    */       
/*    */ 
/* 59 */       if (p.hasPower("Vulnerable")) {
/* 60 */         flash();
/* 61 */         for (AbstractMonster monster : AbstractDungeon.getMonsters().monsters) {
/* 62 */           if ((!monster.isDead) && (!monster.isDying))
/*    */           {
/* 64 */             AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(monster, p, new com.megacrit.cardcrawl.powers.VulnerablePower(monster, this.magicNumber, false), this.magicNumber));
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 75 */     return new ShareWeakness();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 80 */     if (!this.upgraded)
/*    */     {
/* 82 */       upgradeName();
/* 83 */       upgradeMagicNumber(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\ShareWeakness.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */