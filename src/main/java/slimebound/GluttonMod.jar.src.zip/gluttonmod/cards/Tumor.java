/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.ApplyPowerAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Tumor extends AbstractGluttonCard
/*    */ {
/*    */   private static final int DRAWBACK = 1;
/*    */   public static final String ID = "Tumor";
/*    */   public static final String NAME = "Tumor";
/*    */   public static final String DESCRIPTION = "Gain 1 Weak, Frail, and Vulnerable. NL If this card is exhausted, draw !M! cards.";
/*    */   public static final String IMG_PATH = "cards/tumor.png";
/* 19 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 20 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 21 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 0;
/*    */   private static final int MAGIC = 2;
/*    */   private static final int UPGRADE_MAGIC_BONUS = 1;
/*    */   
/*    */   public Tumor()
/*    */   {
/* 29 */     super("Tumor", "Tumor", "cards/tumor.png", 0, "Gain 1 Weak, Frail, and Vulnerable. NL If this card is exhausted, draw !M! cards.", TYPE, RARITY, TARGET);
/*    */     
/* 31 */     this.baseMagicNumber = 2;
/* 32 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 37 */     AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(p, p, new com.megacrit.cardcrawl.powers.WeakPower(p, 1, false), 1));
/*    */     
/* 39 */     AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(p, p, new com.megacrit.cardcrawl.powers.FrailPower(p, 1, false), 1));
/*    */     
/* 41 */     AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(p, p, new com.megacrit.cardcrawl.powers.VulnerablePower(p, 1, false), 1));
/*    */   }
/*    */   
/*    */   public void triggerOnExhaust()
/*    */   {
/* 46 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DrawCardAction(AbstractDungeon.player, this.magicNumber));
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 51 */     return new Tumor();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 56 */     if (!this.upgraded)
/*    */     {
/* 58 */       upgradeName();
/* 59 */       upgradeMagicNumber(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Tumor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */