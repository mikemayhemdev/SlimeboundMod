/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Dispepsia extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Dispepsia";
/*    */   public static final String NAME = "Dispepsia";
/*    */   public static final String DESCRIPTION = "Unplayable. NL When drawn, lose 1 HP and gain [R].";
/*    */   public static final String UPGRADE_DESCRIPTION = "Unplayable. NL When drawn, lose 1 HP and gain [R] [R].";
/*    */   public static final String CANT_PLAY = "I can't play this card.";
/*    */   public static final String IMG_PATH = "cards/dispepsia.png";
/* 20 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 21 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 22 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.NONE;
/*    */   
/*    */   private static final int COST = -2;
/*    */   private static final int PAIN = 1;
/*    */   private static final int UPGRADE_ENERGY_GAIN = 2;
/* 27 */   private int energyGain = 1;
/*    */   
/*    */   public Dispepsia()
/*    */   {
/* 31 */     super("Dispepsia", "Dispepsia", "cards/dispepsia.png", -2, "Unplayable. NL When drawn, lose 1 HP and gain [R].", TYPE, RARITY, TARGET);
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m) {}
/*    */   
/*    */   public boolean canUse(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 38 */     this.cantUseMessage = "I can't play this card.";
/* 39 */     return false;
/*    */   }
/*    */   
/*    */   public void triggerWhenDrawn()
/*    */   {
/* 44 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.LoseHPAction(AbstractDungeon.player, AbstractDungeon.player, 1, com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.FIRE));
/*    */     
/*    */ 
/*    */ 
/* 48 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.GainEnergyAction(this.energyGain));
/*    */   }
/*    */   
/*    */   public AbstractCard makeCopy()
/*    */   {
/* 53 */     return new Dispepsia();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 58 */     if (!this.upgraded)
/*    */     {
/* 60 */       upgradeName();
/* 61 */       this.energyGain = 2;
/* 62 */       this.rawDescription = "Unplayable. NL When drawn, lose 1 HP and gain [R] [R].";
/* 63 */       initializeDescription();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Dispepsia.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */