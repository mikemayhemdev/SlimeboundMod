/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect;
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.DamageAction;
/*    */ import com.megacrit.cardcrawl.actions.common.GainEnergyAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.cards.DamageInfo;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class KneeJerk extends AbstractGluttonCard
/*    */ {
/*    */   public static final int HP_LOSS_CHECK = 3;
/*    */   public static final String ID = "KneeJerk";
/*    */   public static final String NAME = "Knee-Jerk";
/*    */   public static final String DESCRIPTION = "Deal !D! damage. If you have lost at least 3 HP this turn, Gain [R] [R] .";
/*    */   public static final String IMG_PATH = "cards/kneejerk.png";
/* 23 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 24 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 25 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 2;
/*    */   private static final int POWER = 10;
/*    */   private static final int UPGRADE_BONUS = 4;
/*    */   private static final int ENERGY_GAIN = 2;
/*    */   
/*    */   public KneeJerk()
/*    */   {
/* 34 */     super("KneeJerk", "Knee-Jerk", "cards/kneejerk.png", 2, "Deal !D! damage. If you have lost at least 3 HP this turn, Gain [R] [R] .", TYPE, RARITY, TARGET);
/*    */     
/* 36 */     this.baseDamage = 10;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 41 */     AbstractDungeon.actionManager.addToBottom(new DamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn), AbstractGameAction.AttackEffect.SLASH_VERTICAL));
/*    */     
/* 43 */     if (GameActionManager.damageReceivedThisTurn >= 3) {
/* 44 */       AbstractDungeon.actionManager.addToTop(new GainEnergyAction(2));
/*    */     }
/*    */   }
/*    */   
/*    */   public AbstractCard makeCopy()
/*    */   {
/* 50 */     return new KneeJerk();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 55 */     if (!this.upgraded)
/*    */     {
/* 57 */       upgradeName();
/* 58 */       upgradeDamage(4);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\KneeJerk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */