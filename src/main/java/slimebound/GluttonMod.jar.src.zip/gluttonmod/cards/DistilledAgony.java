/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import com.megacrit.cardcrawl.ui.panels.EnergyPanel;
/*    */ import gluttonmod.actions.DistilledAgonyAction;
/*    */ 
/*    */ public class DistilledAgony extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "DistilledAgony";
/*    */   public static final String NAME = "Distilled Agony";
/*    */   public static final String DESCRIPTION = "Lose !M! HP and deal !D! damage X times.";
/*    */   public static final String IMG_PATH = "cards/distilledagony.png";
/* 17 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 18 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 19 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = -1;
/*    */   private static final int MAGIC = 2;
/*    */   private static final int POWER = 10;
/*    */   private static final int UPGRADE_BONUS = 3;
/*    */   
/*    */   public DistilledAgony()
/*    */   {
/* 28 */     super("DistilledAgony", "Distilled Agony", "cards/distilledagony.png", -1, "Lose !M! HP and deal !D! damage X times.", TYPE, RARITY, TARGET);
/*    */     
/* 30 */     this.baseMagicNumber = 2;
/* 31 */     this.baseDamage = 10;
/* 32 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 37 */     if (this.energyOnUse < EnergyPanel.totalCount) {
/* 38 */       this.energyOnUse = EnergyPanel.totalCount;
/*    */     }
/* 40 */     com.megacrit.cardcrawl.dungeons.AbstractDungeon.actionManager.addToBottom(new DistilledAgonyAction(p, m, this.damage, this.magicNumber, this.damageTypeForTurn, this.freeToPlayOnce, this.energyOnUse));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 47 */     return new DistilledAgony();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 52 */     if (!this.upgraded)
/*    */     {
/* 54 */       upgradeName();
/* 55 */       upgradeDamage(3);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\DistilledAgony.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */