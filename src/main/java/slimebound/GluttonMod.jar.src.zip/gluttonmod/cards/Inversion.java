/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.ApplyPowerAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import com.megacrit.cardcrawl.powers.DexterityPower;
/*    */ 
/*    */ public class Inversion extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Inversion";
/*    */   public static final String NAME = "Inversion";
/*    */   public static final String DESCRIPTION = "If you are Weak, gain !M! Strength. NL If you are Frail, gain !M! Dexterity. NL If you are Vulnerable, gain !B! Block.";
/*    */   public static final String IMG_PATH = "cards/inversion.png";
/* 19 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 20 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.RARE;
/* 21 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 2;
/*    */   private static final int UPGRADE_MAGIC_BONUS = 1;
/*    */   private static final int BLOCK = 15;
/*    */   private static final int UPGRADE_BLOCK_BONUS = 5;
/*    */   
/*    */   public Inversion()
/*    */   {
/* 31 */     super("Inversion", "Inversion", "cards/inversion.png", 1, "If you are Weak, gain !M! Strength. NL If you are Frail, gain !M! Dexterity. NL If you are Vulnerable, gain !B! Block.", TYPE, RARITY, TARGET);
/*    */     
/* 33 */     this.baseMagicNumber = 2;
/* 34 */     this.magicNumber = this.baseMagicNumber;
/* 35 */     this.baseBlock = 15;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 40 */     if (p.hasPower("Weakened")) {
/* 41 */       AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(p, p, new com.megacrit.cardcrawl.powers.StrengthPower(p, this.magicNumber), this.magicNumber));
/*    */     }
/*    */     
/* 44 */     if (p.hasPower("Frail")) {
/* 45 */       AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(p, p, new DexterityPower(p, this.magicNumber), this.magicNumber));
/*    */     }
/*    */     
/* 48 */     if (p.hasPower("Vulnerable")) {
/* 49 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.GainBlockAction(p, p, this.block));
/*    */     }
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 55 */     return new Inversion();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 60 */     if (!this.upgraded)
/*    */     {
/* 62 */       upgradeName();
/* 63 */       upgradeMagicNumber(1);
/* 64 */       upgradeBlock(5);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Inversion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */