/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.animations.VFXAction;
/*    */ import com.megacrit.cardcrawl.actions.common.MakeTempCardInDiscardAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.cards.CardGroup;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Excrescence extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Excrescence";
/*    */   public static final String NAME = "Excrescence";
/*    */   public static final String DESCRIPTION = "Deal damage equal to the number of cards in your deck. Shuffle !M! Hunger_Pangs into your discard pile.";
/*    */   public static final String EXTENDED_DESCRIPTION = " NL (Deals !D! damage.)";
/*    */   public static final String IMG_PATH = "cards/excrescence.png";
/* 21 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 22 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.RARE;
/* 23 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 2;
/*    */   private static final int MAGIC = 2;
/*    */   private static final int POWER = 0;
/*    */   private static final int UPGRADE_COST = 1;
/*    */   
/*    */   public Excrescence()
/*    */   {
/* 32 */     super("Excrescence", "Excrescence", "cards/excrescence.png", 2, "Deal damage equal to the number of cards in your deck. Shuffle !M! Hunger_Pangs into your discard pile.", TYPE, RARITY, TARGET);
/*    */     
/* 34 */     this.baseMagicNumber = 2;
/* 35 */     this.baseDamage = 0;
/* 36 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 41 */     AbstractDungeon.actionManager.addToBottom(new VFXAction(new com.megacrit.cardcrawl.vfx.combat.MindblastEffect(p.dialogX, p.dialogY, p.flipHorizontal)));
/* 42 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(m, new com.megacrit.cardcrawl.cards.DamageInfo(p, this.damage, com.megacrit.cardcrawl.cards.DamageInfo.DamageType.NORMAL), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.NONE));
/*    */     
/* 44 */     AbstractDungeon.actionManager.addToBottom(new MakeTempCardInDiscardAction(new HungerPang(), this.magicNumber));
/*    */     
/*    */ 
/* 47 */     this.rawDescription = "Deal damage equal to the number of cards in your deck. Shuffle !M! Hunger_Pangs into your discard pile.";
/* 48 */     initializeDescription();
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 53 */     return new Excrescence();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void applyPowers()
/*    */   {
/* 60 */     this.baseDamage = (AbstractDungeon.player.drawPile.size() + AbstractDungeon.player.discardPile.size() + AbstractDungeon.player.hand.size());
/* 61 */     super.applyPowers();
/* 62 */     this.rawDescription = "Deal damage equal to the number of cards in your deck. Shuffle !M! Hunger_Pangs into your discard pile. NL (Deals !D! damage.)";
/* 63 */     initializeDescription();
/*    */   }
/*    */   
/*    */   public void calculateCardDamage(AbstractMonster mo)
/*    */   {
/* 68 */     super.calculateCardDamage(mo);
/* 69 */     this.rawDescription = "Deal damage equal to the number of cards in your deck. Shuffle !M! Hunger_Pangs into your discard pile. NL (Deals !D! damage.)";
/* 70 */     initializeDescription();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 75 */     if (!this.upgraded)
/*    */     {
/* 77 */       upgradeName();
/* 78 */       upgradeBaseCost(1);
/* 79 */       initializeDescription();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Excrescence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */