/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.animations.VFXAction;
/*    */ import com.megacrit.cardcrawl.actions.common.HealAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.core.Settings;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.helpers.Hitbox;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Chomp extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Chomp";
/*    */   public static final String NAME = "Chomp";
/*    */   public static final String DESCRIPTION = "Deal !D! damage. NL Heal for unblocked damage dealt. Exhaust.";
/*    */   public static final String IMG_PATH = "cards/chomp.png";
/* 21 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 22 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 23 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 3;
/*    */   private static final int POWER = 16;
/*    */   private static final int UPGRADE_BONUS = 5;
/*    */   
/*    */   public Chomp()
/*    */   {
/* 31 */     super("Chomp", "Chomp", "cards/chomp.png", 3, "Deal !D! damage. NL Heal for unblocked damage dealt. Exhaust.", TYPE, RARITY, TARGET);
/*    */     
/* 33 */     this.baseDamage = 16;
/* 34 */     this.exhaust = true;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 39 */     if (m != null) {
/* 40 */       AbstractDungeon.actionManager.addToBottom(new VFXAction(new com.megacrit.cardcrawl.vfx.combat.BiteEffect(m.hb.cX, m.hb.cY - 40.0F * Settings.scale, Settings.GOLD_COLOR
/* 41 */         .cpy()), 0.3F));
/*    */     }
/* 43 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(m, new com.megacrit.cardcrawl.cards.DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.NONE));
/*    */     
/*    */ 
/* 46 */     int healAmount = this.damage;
/* 47 */     healAmount -= m.currentBlock;
/* 48 */     if (healAmount > m.currentHealth) {
/* 49 */       healAmount = m.currentHealth;
/*    */     }
/* 51 */     if (healAmount > 0) {
/* 52 */       AbstractDungeon.actionManager.addToBottom(new HealAction(p, p, healAmount));
/*    */     }
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 58 */     return new Chomp();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 63 */     if (!this.upgraded)
/*    */     {
/* 65 */       upgradeName();
/* 66 */       upgradeDamage(5);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Chomp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */