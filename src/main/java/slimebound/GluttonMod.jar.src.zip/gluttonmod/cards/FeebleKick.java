/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.DamageAction;
/*    */ import com.megacrit.cardcrawl.actions.common.GainEnergyAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.cards.DamageInfo;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import gluttonmod.GluttonMod;
/*    */ 
/*    */ public class FeebleKick extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "FeebleKick";
/*    */   public static final String NAME = "Feeble Kick";
/*    */   public static final String DESCRIPTION = "Deal !D! damage. If you have a debuff, Gain [R] and draw 1 card.";
/*    */   public static final String IMG_PATH = "cards/feeblekick.png";
/* 22 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 23 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 24 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int POWER = 7;
/*    */   private static final int UPGRADE_BONUS = 3;
/*    */   private static final int CARD_DRAW = 1;
/*    */   private static final int ENERGY_GAIN = 1;
/*    */   
/*    */   public FeebleKick()
/*    */   {
/* 34 */     super("FeebleKick", "Feeble Kick", "cards/feeblekick.png", 1, "Deal !D! damage. If you have a debuff, Gain [R] and draw 1 card.", TYPE, RARITY, TARGET);
/*    */     
/* 36 */     this.baseDamage = 7;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 41 */     AbstractDungeon.actionManager.addToBottom(new DamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.SLASH_VERTICAL));
/*    */     
/* 43 */     if (GluttonMod.hasDebuff(AbstractDungeon.player)) {
/* 44 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DrawCardAction(p, 1));
/* 45 */       AbstractDungeon.actionManager.addToTop(new GainEnergyAction(1));
/*    */     }
/*    */   }
/*    */   
/*    */   public AbstractCard makeCopy()
/*    */   {
/* 51 */     return new FeebleKick();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 56 */     if (!this.upgraded)
/*    */     {
/* 58 */       upgradeName();
/* 59 */       upgradeDamage(3);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\FeebleKick.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */