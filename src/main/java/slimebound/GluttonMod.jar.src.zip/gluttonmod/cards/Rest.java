/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.HealAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTags;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Rest extends AbstractGluttonCard
/*    */ {
/*    */   private static final int HEAL = 10;
/*    */   public static final String ID = "Rest";
/*    */   public static final String NAME = "Rest";
/*    */   public static final String DESCRIPTION = "Gain !M! Vulnerable. NL Heal 10 HP. NL Exhaust.";
/*    */   public static final String IMG_PATH = "cards/rest.png";
/* 20 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 21 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 22 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 2;
/*    */   private static final int UPGRADE_MAGIC_BONUS = -1;
/*    */   
/*    */   public Rest()
/*    */   {
/* 30 */     super("Rest", "Rest", "cards/rest.png", 1, "Gain !M! Vulnerable. NL Heal 10 HP. NL Exhaust.", TYPE, RARITY, TARGET);
/*    */     
/* 32 */     this.baseMagicNumber = 2;
/* 33 */     this.magicNumber = this.baseMagicNumber;
/* 34 */     this.tags.add(AbstractCard.CardTags.HEALING);
/* 35 */     this.exhaust = true;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 40 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.ApplyPowerAction(p, p, new com.megacrit.cardcrawl.powers.VulnerablePower(p, this.magicNumber, false), this.magicNumber));
/*    */     
/* 42 */     AbstractDungeon.actionManager.addToBottom(new HealAction(p, p, 10));
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 47 */     return new Rest();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 52 */     if (!this.upgraded)
/*    */     {
/* 54 */       upgradeName();
/* 55 */       upgradeMagicNumber(-1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Rest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */