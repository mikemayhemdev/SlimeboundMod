/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect;
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.DamageAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.cards.DamageInfo;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class DecrepitStrike extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "DecrepitStrike";
/*    */   public static final String NAME = "Decrepit Strike";
/*    */   public static final String DESCRIPTION = "Deal !D! damage. If you are Weak, Deal !D! damage two additional times.";
/*    */   public static final String IMG_PATH = "cards/decrepitstrike.png";
/* 18 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 19 */   private static final com.megacrit.cardcrawl.cards.AbstractCard.CardRarity RARITY = com.megacrit.cardcrawl.cards.AbstractCard.CardRarity.UNCOMMON;
/* 20 */   private static final com.megacrit.cardcrawl.cards.AbstractCard.CardTarget TARGET = com.megacrit.cardcrawl.cards.AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int POWER = 10;
/*    */   private static final int UPGRADE_BONUS = 3;
/*    */   
/*    */   public DecrepitStrike()
/*    */   {
/* 28 */     super("DecrepitStrike", "Decrepit Strike", "cards/decrepitstrike.png", 1, "Deal !D! damage. If you are Weak, Deal !D! damage two additional times.", TYPE, RARITY, TARGET);
/*    */     
/* 30 */     this.baseDamage = 10;
/* 31 */     this.tags.add(com.megacrit.cardcrawl.cards.AbstractCard.CardTags.STRIKE);
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 36 */     AbstractDungeon.actionManager.addToBottom(new DamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn), AbstractGameAction.AttackEffect.SLASH_VERTICAL));
/*    */     
/* 38 */     if (p.hasPower("Weakened")) {
/* 39 */       AbstractDungeon.actionManager.addToBottom(new DamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn), AbstractGameAction.AttackEffect.SLASH_HORIZONTAL));
/*    */       
/*    */ 
/* 42 */       AbstractDungeon.actionManager.addToBottom(new DamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn), AbstractGameAction.AttackEffect.SLASH_DIAGONAL));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 49 */     return new DecrepitStrike();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 54 */     if (!this.upgraded)
/*    */     {
/* 56 */       upgradeName();
/* 57 */       upgradeDamage(3);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\DecrepitStrike.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */