/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class GuardStance extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "GuardStance";
/*    */   public static final String NAME = "Guard Stance";
/*    */   public static final String DESCRIPTION = "Gain !B! block. NL Heal !M! HP. NL Exhaust.";
/*    */   public static final String IMG_PATH = "cards/guardstance.png";
/* 17 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 18 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 19 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 2;
/*    */   private static final int BLOCK = 8;
/*    */   private static final int MAGIC = 8;
/*    */   private static final int UPGRADE_BONUS = 4;
/*    */   
/*    */   public GuardStance()
/*    */   {
/* 28 */     super("GuardStance", "Guard Stance", "cards/guardstance.png", 2, "Gain !B! block. NL Heal !M! HP. NL Exhaust.", TYPE, RARITY, TARGET);
/*    */     
/* 30 */     this.baseBlock = 8;
/* 31 */     this.baseMagicNumber = 8;
/* 32 */     this.magicNumber = this.baseMagicNumber;
/* 33 */     this.exhaust = true;
/* 34 */     this.tags.add(com.megacrit.cardcrawl.cards.AbstractCard.CardTags.HEALING);
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 39 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.GainBlockAction(p, p, this.block));
/* 40 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.HealAction(p, p, this.magicNumber));
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 45 */     return new GuardStance();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 50 */     if (!this.upgraded)
/*    */     {
/* 52 */       upgradeName();
/* 53 */       upgradeBlock(4);
/* 54 */       upgradeMagicNumber(4);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\GuardStance.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */