/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.ApplyPowerAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import com.megacrit.cardcrawl.monsters.MonsterGroup;
/*    */ 
/*    */ public class Hemophilia extends AbstractGluttonCard
/*    */ {
/* 12 */   private static int PAIN = 1;
/*    */   public static final String ID = "Hemophilia";
/*    */   public static final String NAME = "Hemophilia";
/* 15 */   public static final String DESCRIPTION = "Gain " + PAIN + " Bleed. Apply !M! Bleed to ALL enemies.";
/*    */   
/*    */   public static final String IMG_PATH = "cards/hemophilia.png";
/* 18 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 19 */   private static final com.megacrit.cardcrawl.cards.AbstractCard.CardRarity RARITY = com.megacrit.cardcrawl.cards.AbstractCard.CardRarity.RARE;
/* 20 */   private static final com.megacrit.cardcrawl.cards.AbstractCard.CardTarget TARGET = com.megacrit.cardcrawl.cards.AbstractCard.CardTarget.ALL;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 3;
/*    */   private static final int UPGRADE_MAGIC_BONUS = 1;
/*    */   
/*    */   public Hemophilia()
/*    */   {
/* 28 */     super("Hemophilia", "Hemophilia", "cards/hemophilia.png", 1, DESCRIPTION, TYPE, RARITY, TARGET);
/*    */     
/* 30 */     this.baseMagicNumber = 3;
/* 31 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(com.megacrit.cardcrawl.characters.AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 36 */     if (!AbstractDungeon.getMonsters().areMonstersBasicallyDead())
/*    */     {
/* 38 */       AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(p, p, new gluttonmod.powers.BleedPower(p, p, PAIN), PAIN));
/*    */       
/*    */ 
/* 41 */       for (AbstractMonster monster : AbstractDungeon.getMonsters().monsters) {
/* 42 */         if ((!monster.isDead) && (!monster.isDying))
/*    */         {
/* 44 */           AbstractDungeon.actionManager.addToBottom(new ApplyPowerAction(monster, p, new gluttonmod.powers.BleedPower(monster, p, this.magicNumber), this.magicNumber));
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 54 */     return new Hemophilia();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 59 */     if (!this.upgraded)
/*    */     {
/* 61 */       upgradeName();
/* 62 */       upgradeMagicNumber(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Hemophilia.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */