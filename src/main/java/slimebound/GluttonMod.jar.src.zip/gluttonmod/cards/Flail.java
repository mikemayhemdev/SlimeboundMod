/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.cards.DamageInfo;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Flail extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Flail";
/*    */   public static final String NAME = "Flail";
/*    */   public static final String DESCRIPTION = "Lose !M! HP. Deal !D! damage.";
/*    */   public static final String IMG_PATH = "cards/flail.png";
/* 19 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 20 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.BASIC;
/* 21 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 3;
/*    */   private static final int POWER = 10;
/*    */   private static final int UPGRADE_BONUS = 5;
/*    */   
/*    */   public Flail()
/*    */   {
/* 30 */     super("Flail", "Flail", "cards/flail.png", 1, "Lose !M! HP. Deal !D! damage.", TYPE, RARITY, TARGET);
/*    */     
/* 32 */     this.baseMagicNumber = 3;
/* 33 */     this.baseDamage = 10;
/* 34 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 39 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.LoseHPAction(p, p, this.magicNumber));
/* 40 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.SLASH_HEAVY));
/*    */   }
/*    */   
/*    */ 
/*    */   public AbstractCard makeCopy()
/*    */   {
/* 46 */     return new Flail();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 51 */     if (!this.upgraded)
/*    */     {
/* 53 */       upgradeName();
/* 54 */       upgradeDamage(5);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Flail.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */