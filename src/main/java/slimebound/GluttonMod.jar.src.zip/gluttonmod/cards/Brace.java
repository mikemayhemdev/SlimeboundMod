/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Brace extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Brace";
/*    */   public static final String NAME = "Brace";
/*    */   public static final String DESCRIPTION = "Lose !M! HP. NL Gain !B! block.";
/*    */   public static final String IMG_PATH = "cards/brace.png";
/* 17 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 18 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 19 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 5;
/*    */   private static final int BLOCK = 20;
/*    */   private static final int UPGRADE_BONUS = 5;
/*    */   
/*    */   public Brace()
/*    */   {
/* 28 */     super("Brace", "Brace", "cards/brace.png", 1, "Lose !M! HP. NL Gain !B! block.", TYPE, RARITY, TARGET);
/*    */     
/* 30 */     this.baseMagicNumber = 5;
/* 31 */     this.baseBlock = 20;
/* 32 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 37 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.LoseHPAction(p, p, this.magicNumber));
/* 38 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.GainBlockAction(p, p, this.block));
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 43 */     return new Brace();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 48 */     if (!this.upgraded)
/*    */     {
/* 50 */       upgradeName();
/* 51 */       upgradeBlock(5);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Brace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */