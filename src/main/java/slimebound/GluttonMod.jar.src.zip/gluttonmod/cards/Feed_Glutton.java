/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTags;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Feed_Glutton extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Feed_Glutton";
/*    */   public static final String NAME = "Feed";
/*    */   public static final String DESCRIPTION = "Deal !D! damage. NL If this kills a NL non-minion enemy, NL raise your Max HP by !M!. Exhaust.";
/*    */   public static final String IMG_PATH = "cards/feed.png";
/* 17 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 18 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 19 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 3;
/*    */   private static final int POWER = 10;
/*    */   private static final int UPGRADE_POWER_BONUS = 2;
/*    */   private static final int UPGRADE_MAGIC_BONUS = 1;
/*    */   
/*    */   public Feed_Glutton()
/*    */   {
/* 29 */     super("Feed_Glutton", "Feed", "cards/feed.png", 1, "Deal !D! damage. NL If this kills a NL non-minion enemy, NL raise your Max HP by !M!. Exhaust.", TYPE, RARITY, TARGET);
/*    */     
/* 31 */     this.baseMagicNumber = 3;
/* 32 */     this.baseDamage = 10;
/* 33 */     this.exhaust = true;
/* 34 */     this.magicNumber = this.baseMagicNumber;
/* 35 */     this.tags.add(AbstractCard.CardTags.HEALING);
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 40 */     com.megacrit.cardcrawl.dungeons.AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.unique.FeedAction(m, new com.megacrit.cardcrawl.cards.DamageInfo(p, this.damage, this.damageTypeForTurn), this.magicNumber));
/*    */   }
/*    */   
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 46 */     return new Feed_Glutton();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 51 */     if (!this.upgraded)
/*    */     {
/* 53 */       upgradeName();
/* 54 */       upgradeDamage(2);
/* 55 */       upgradeMagicNumber(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Feed_Glutton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */