/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Torment extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Torment";
/*    */   public static final String NAME = "Torment";
/*    */   public static final String DESCRIPTION = "Can only be played if you have lost life !M! or more times this combat. NL Deal !D! damage.";
/* 16 */   public static final String[] EXTENDED_DESCRIPTION = { " NL (Lost life ", " time.)", " times.)" };
/*    */   
/*    */   public static final String CANT_PLAY = "I'm not really feeling it.";
/*    */   public static final String IMG_PATH = "cards/torment.png";
/* 20 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 21 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 22 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 2;
/*    */   private static final int POWER = 30;
/*    */   private static final int MAGIC = 15;
/*    */   private static final int UPGRADE_BONUS = -5;
/*    */   
/*    */   public Torment()
/*    */   {
/* 31 */     super("Torment", "Torment", "cards/torment.png", 2, "Can only be played if you have lost life !M! or more times this combat. NL Deal !D! damage.", TYPE, RARITY, TARGET);
/*    */     
/* 33 */     this.baseDamage = 30;
/* 34 */     this.baseMagicNumber = 15;
/* 35 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 40 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(m, new com.megacrit.cardcrawl.cards.DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.SLASH_HEAVY));
/*    */     
/* 42 */     this.rawDescription = "Can only be played if you have lost life !M! or more times this combat. NL Deal !D! damage.";
/* 43 */     initializeDescription();
/*    */   }
/*    */   
/*    */   public boolean canUse(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 48 */     boolean canUse = super.canUse(p, m);
/* 49 */     if (!canUse) {
/* 50 */       return false;
/*    */     }
/* 52 */     if (p.damagedThisCombat < this.magicNumber) {
/* 53 */       this.cantUseMessage = "I'm not really feeling it.";
/* 54 */       return false;
/*    */     }
/* 56 */     return true;
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 61 */     return new Torment();
/*    */   }
/*    */   
/*    */   public void applyPowers()
/*    */   {
/* 66 */     super.applyPowers();
/* 67 */     int times = AbstractDungeon.player.damagedThisCombat;
/* 68 */     if (times == 1) {
/* 69 */       this.rawDescription = ("Can only be played if you have lost life !M! or more times this combat. NL Deal !D! damage." + EXTENDED_DESCRIPTION[0] + times + EXTENDED_DESCRIPTION[1]);
/*    */     }
/*    */     else {
/* 72 */       this.rawDescription = ("Can only be played if you have lost life !M! or more times this combat. NL Deal !D! damage." + EXTENDED_DESCRIPTION[0] + times + EXTENDED_DESCRIPTION[2]);
/*    */     }
/* 74 */     initializeDescription();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 79 */     if (!this.upgraded)
/*    */     {
/* 81 */       upgradeName();
/* 82 */       upgradeMagicNumber(-5);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Torment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */