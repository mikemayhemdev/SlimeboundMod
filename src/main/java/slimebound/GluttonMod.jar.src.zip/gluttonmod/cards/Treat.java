/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Treat extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Treat";
/*    */   public static final String NAME = "Treat";
/*    */   public static final String DESCRIPTION = "Gain !B! block. NL If this card is Exhausted, gain !M! Maximum HP.";
/*    */   public static final String IMG_PATH = "cards/treat.png";
/* 16 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 17 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 18 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int BLOCK = 8;
/*    */   private static final int MAGIC = 2;
/*    */   private static final int UPGRADE_BONUS = 2;
/*    */   
/*    */   public Treat()
/*    */   {
/* 27 */     super("Treat", "Treat", "cards/treat.png", 1, "Gain !B! block. NL If this card is Exhausted, gain !M! Maximum HP.", TYPE, RARITY, TARGET);
/*    */     
/* 29 */     this.baseBlock = 8;
/* 30 */     this.baseMagicNumber = 2;
/* 31 */     this.magicNumber = this.baseMagicNumber;
/* 32 */     this.tags.add(com.megacrit.cardcrawl.cards.AbstractCard.CardTags.HEALING);
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 37 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.GainBlockAction(p, p, this.block));
/*    */   }
/*    */   
/*    */   public void triggerOnExhaust()
/*    */   {
/* 42 */     AbstractDungeon.player.increaseMaxHp(this.magicNumber, false);
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 47 */     return new Treat();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 52 */     if (!this.upgraded)
/*    */     {
/* 54 */       upgradeName();
/* 55 */       upgradeBlock(2);
/* 56 */       upgradeMagicNumber(2);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Treat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */