/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class FeverVisions extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "FeverVisions";
/*    */   public static final String NAME = "Fever Visions";
/*    */   public static final String DESCRIPTION = "At the start of your turn, if you have a debuff, draw !M! card.";
/*    */   public static final String UPGRADE_DESCRIPTION = "At the start of your turn, if you have a debuff, draw !M! cards.";
/*    */   public static final String IMG_PATH = "cards/fevervisions.png";
/* 18 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.POWER;
/* 19 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 20 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 0;
/*    */   private static final int MAGIC = 1;
/*    */   private static final int UPGRADE_BONUS = 1;
/*    */   
/*    */   public FeverVisions()
/*    */   {
/* 28 */     super("FeverVisions", "Fever Visions", "cards/fevervisions.png", 0, "At the start of your turn, if you have a debuff, draw !M! card.", TYPE, RARITY, TARGET);
/*    */     
/* 30 */     this.baseMagicNumber = 1;
/* 31 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 36 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.ApplyPowerAction(p, p, new gluttonmod.powers.FeverVisionsPower(p, this.magicNumber), this.magicNumber));
/*    */   }
/*    */   
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 42 */     return new FeverVisions();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 47 */     if (!this.upgraded)
/*    */     {
/* 49 */       upgradeName();
/* 50 */       upgradeMagicNumber(1);
/* 51 */       this.rawDescription = "At the start of your turn, if you have a debuff, draw !M! cards.";
/* 52 */       initializeDescription();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\FeverVisions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */