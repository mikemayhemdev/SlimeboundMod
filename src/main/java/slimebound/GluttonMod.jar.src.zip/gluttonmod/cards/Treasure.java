/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.helpers.Hitbox;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class Treasure extends AbstractGluttonCard
/*    */ {
/*    */   private static final int GOLD = 50;
/*    */   private static final int EXCHANGE = 100;
/*    */   public static final String ID = "Treasure";
/*    */   public static final String NAME = "Treasure";
/*    */   public static final String DESCRIPTION = "Gain 50 Gold. NL Heal !M! HP for every 100 Gold you have. NL Exhaust.";
/*    */   public static final String IMG_PATH = "cards/treasure.png";
/* 21 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 22 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.RARE;
/* 23 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 2;
/*    */   private static final int MAGIC = 1;
/*    */   private static final int UPGRADE_MAGIC_BONUS = 1;
/*    */   
/*    */   public Treasure()
/*    */   {
/* 31 */     super("Treasure", "Treasure", "cards/treasure.png", 2, "Gain 50 Gold. NL Heal !M! HP for every 100 Gold you have. NL Exhaust.", TYPE, RARITY, TARGET);
/*    */     
/* 33 */     this.baseMagicNumber = 1;
/* 34 */     this.magicNumber = this.baseMagicNumber;
/* 35 */     this.tags.add(com.megacrit.cardcrawl.cards.AbstractCard.CardTags.HEALING);
/* 36 */     this.exhaust = true;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 41 */     p.gainGold(50);
/* 42 */     for (int i = 0; i < 50; i++) {
/* 43 */       AbstractDungeon.effectList.add(new com.megacrit.cardcrawl.vfx.GainPennyEffect(p, 0.0F, 0.0F, p.hb.cX, p.hb.cY, true));
/*    */     }
/* 45 */     int heal = p.gold / 100 * this.magicNumber;
/* 46 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.HealAction(p, p, heal));
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 51 */     return new Treasure();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 56 */     if (!this.upgraded)
/*    */     {
/* 58 */       upgradeName();
/* 59 */       upgradeMagicNumber(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Treasure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */