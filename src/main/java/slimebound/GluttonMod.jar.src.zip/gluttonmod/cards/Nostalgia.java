/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Nostalgia extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Nostalgia";
/*    */   public static final String NAME = "Nostalgia";
/*    */   public static final String DESCRIPTION = "Whenever you exhaust a non-ethereal Skill or Attack, create an echo of it.";
/*    */   public static final String IMG_PATH = "cards/nostalgia.png";
/* 18 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.POWER;
/* 19 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.RARE;
/* 20 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 2;
/*    */   private static final int UPGRADE_COST = 1;
/*    */   
/*    */   public Nostalgia()
/*    */   {
/* 27 */     super("Nostalgia", "Nostalgia", "cards/nostalgia.png", 2, "Whenever you exhaust a non-ethereal Skill or Attack, create an echo of it.", TYPE, RARITY, TARGET);
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 32 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.ApplyPowerAction(p, p, new gluttonmod.powers.NostalgiaPower(p, 1), 1));
/*    */   }
/*    */   
/*    */ 
/*    */   public AbstractCard makeCopy()
/*    */   {
/* 38 */     return new Nostalgia();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 43 */     if (!this.upgraded)
/*    */     {
/* 45 */       upgradeName();
/* 46 */       upgradeBaseCost(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Nostalgia.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */