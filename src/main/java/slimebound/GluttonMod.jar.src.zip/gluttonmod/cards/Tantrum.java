/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.cards.DamageInfo;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import com.megacrit.cardcrawl.monsters.MonsterGroup;
/*    */ 
/*    */ public class Tantrum extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Tantrum";
/*    */   public static final String NAME = "Tantrum";
/*    */   public static final String DESCRIPTION = "Deal !D! damage to a random enemy. NL If this card is Exhausted, deal !D! damage to the enemy with the least HP.";
/*    */   public static final String IMG_PATH = "cards/tantrum.png";
/* 17 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 18 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 19 */   private static final com.megacrit.cardcrawl.cards.AbstractCard.CardTarget TARGET = com.megacrit.cardcrawl.cards.AbstractCard.CardTarget.ALL_ENEMY;
/*    */   
/*    */   private static final int COST = 2;
/*    */   private static final int POWER = 16;
/*    */   private static final int UPGRADE_BONUS = 5;
/*    */   
/*    */   public Tantrum()
/*    */   {
/* 27 */     super("Tantrum", "Tantrum", "cards/tantrum.png", 2, "Deal !D! damage to a random enemy. NL If this card is Exhausted, deal !D! damage to the enemy with the least HP.", TYPE, RARITY, TARGET);
/*    */     
/* 29 */     this.baseDamage = 16;
/*    */   }
/*    */   
/*    */   public void use(com.megacrit.cardcrawl.characters.AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 34 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(
/* 35 */       AbstractDungeon.getMonsters().getRandomMonster(true), new DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.SLASH_DIAGONAL));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void triggerOnExhaust()
/*    */   {
/* 42 */     AbstractMonster weakestMonster = null;
/* 43 */     for (AbstractMonster m : AbstractDungeon.getMonsters().monsters) {
/* 44 */       if (!m.isDeadOrEscaped()) {
/* 45 */         if (weakestMonster == null) {
/* 46 */           weakestMonster = m;
/* 47 */         } else if (m.currentHealth < weakestMonster.currentHealth) {
/* 48 */           weakestMonster = m;
/*    */         }
/*    */       }
/*    */     }
/* 52 */     if (weakestMonster != null) {
/* 53 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(weakestMonster, new DamageInfo(AbstractDungeon.player, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.SLASH_DIAGONAL));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 62 */     return new Tantrum();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 67 */     if (!this.upgraded)
/*    */     {
/* 69 */       upgradeName();
/* 70 */       upgradeDamage(5);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Tantrum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */