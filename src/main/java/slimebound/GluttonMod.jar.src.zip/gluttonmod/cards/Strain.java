/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.cards.DamageInfo;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Strain extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Strain";
/*    */   public static final String NAME = "Strain";
/*    */   public static final String DESCRIPTION = "Deal !D! damage. Gain !M! Weak for yourself.";
/*    */   public static final String IMG_PATH = "cards/strain.png";
/* 19 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 20 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 21 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 1;
/*    */   private static final int POWER = 12;
/*    */   private static final int UPGRADE_BONUS = 5;
/*    */   
/*    */   public Strain()
/*    */   {
/* 30 */     super("Strain", "Strain", "cards/strain.png", 1, "Deal !D! damage. Gain !M! Weak for yourself.", TYPE, RARITY, TARGET);
/*    */     
/* 32 */     this.baseMagicNumber = 1;
/* 33 */     this.baseDamage = 12;
/* 34 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 39 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.SLASH_HORIZONTAL));
/*    */     
/* 41 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.ApplyPowerAction(p, p, new com.megacrit.cardcrawl.powers.WeakPower(p, this.magicNumber, false), this.magicNumber));
/*    */   }
/*    */   
/*    */ 
/*    */   public AbstractCard makeCopy()
/*    */   {
/* 47 */     return new Strain();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 52 */     if (!this.upgraded)
/*    */     {
/* 54 */       upgradeName();
/* 55 */       upgradeDamage(5);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Strain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */