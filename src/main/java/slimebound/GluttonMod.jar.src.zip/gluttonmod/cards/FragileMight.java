/*     */ package gluttonmod.cards;
/*     */ 
/*     */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*     */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*     */ import com.megacrit.cardcrawl.cards.DamageInfo;
/*     */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*     */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*     */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*     */ import com.megacrit.cardcrawl.powers.AbstractPower;
/*     */ import com.megacrit.cardcrawl.powers.AbstractPower.PowerType;
/*     */ 
/*     */ public class FragileMight extends AbstractGluttonCard
/*     */ {
/*     */   public static final String ID = "FragileMight";
/*     */   public static final String NAME = "Fragile Might";
/*     */   public static final String DESCRIPTION = "Deal !D! damage. Double the number of hits for each debuff you have.";
/*  17 */   public static final String[] EXTENDED_DESCRIPTION = { " NL Hits", "1 time.", "times." };
/*     */   
/*     */   public static final String IMG_PATH = "cards/fragilemight.png";
/*  20 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/*  21 */   private static final com.megacrit.cardcrawl.cards.AbstractCard.CardRarity RARITY = com.megacrit.cardcrawl.cards.AbstractCard.CardRarity.RARE;
/*  22 */   private static final com.megacrit.cardcrawl.cards.AbstractCard.CardTarget TARGET = com.megacrit.cardcrawl.cards.AbstractCard.CardTarget.ENEMY;
/*     */   
/*     */   private static final int COST = 2;
/*     */   private static final int POWER = 5;
/*     */   private static final int UPGRADE_POWER = 2;
/*     */   
/*     */   public FragileMight()
/*     */   {
/*  30 */     super("FragileMight", "Fragile Might", "cards/fragilemight.png", 2, "Deal !D! damage. Double the number of hits for each debuff you have.", TYPE, RARITY, TARGET);
/*     */     
/*  32 */     this.baseDamage = 5;
/*     */   }
/*     */   
/*     */   public void use(AbstractPlayer p, AbstractMonster m)
/*     */   {
/*  37 */     int timesHit = 1;
/*  38 */     for (AbstractPower power : AbstractDungeon.player.powers) {
/*  39 */       if (power.type == AbstractPower.PowerType.DEBUFF) {
/*  40 */         timesHit *= 2;
/*     */       }
/*     */     }
/*  43 */     for (int i = 0; i < timesHit - 1; i++) {
/*  44 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.PummelDamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn)));
/*     */     }
/*     */     
/*  47 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.BLUNT_HEAVY));
/*     */     
/*     */ 
/*  50 */     this.rawDescription = "Deal !D! damage. Double the number of hits for each debuff you have.";
/*  51 */     initializeDescription();
/*     */   }
/*     */   
/*     */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*     */   {
/*  56 */     return new FragileMight();
/*     */   }
/*     */   
/*     */   public void applyPowers()
/*     */   {
/*  61 */     int timesHit = 1;
/*  62 */     for (AbstractPower power : AbstractDungeon.player.powers) {
/*  63 */       if (power.type == AbstractPower.PowerType.DEBUFF) {
/*  64 */         timesHit *= 2;
/*     */       }
/*     */     }
/*  67 */     super.applyPowers();
/*  68 */     if (timesHit == 1) {
/*  69 */       this.rawDescription = ("Deal !D! damage. Double the number of hits for each debuff you have." + EXTENDED_DESCRIPTION[0] + " " + EXTENDED_DESCRIPTION[1]);
/*     */     }
/*     */     else {
/*  72 */       this.rawDescription = ("Deal !D! damage. Double the number of hits for each debuff you have." + EXTENDED_DESCRIPTION[0] + " " + timesHit + " " + EXTENDED_DESCRIPTION[2]);
/*     */     }
/*     */     
/*  75 */     initializeDescription();
/*     */   }
/*     */   
/*     */   public void calculateCardDamage(AbstractMonster mo)
/*     */   {
/*  80 */     super.calculateCardDamage(mo);
/*  81 */     int timesHit = 1;
/*  82 */     for (AbstractPower power : AbstractDungeon.player.powers) {
/*  83 */       if (power.type == AbstractPower.PowerType.DEBUFF) {
/*  84 */         timesHit *= 2;
/*     */       }
/*     */     }
/*  87 */     if (timesHit == 1) {
/*  88 */       this.rawDescription = ("Deal !D! damage. Double the number of hits for each debuff you have." + EXTENDED_DESCRIPTION[0] + " " + EXTENDED_DESCRIPTION[1]);
/*     */     }
/*     */     else {
/*  91 */       this.rawDescription = ("Deal !D! damage. Double the number of hits for each debuff you have." + EXTENDED_DESCRIPTION[0] + " " + timesHit + " " + EXTENDED_DESCRIPTION[2]);
/*     */     }
/*     */     
/*  94 */     initializeDescription();
/*     */   }
/*     */   
/*     */   public void upgrade()
/*     */   {
/*  99 */     if (!this.upgraded)
/*     */     {
/* 101 */       upgradeName();
/* 102 */       upgradeDamage(2);
/* 103 */       initializeDescription();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\FragileMight.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */