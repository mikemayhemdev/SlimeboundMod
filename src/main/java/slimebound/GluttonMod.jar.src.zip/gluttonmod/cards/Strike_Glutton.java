/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import basemod.helpers.BaseModCardTags;
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTags;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class Strike_Glutton extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Strike_Glutton";
/*    */   public static final String NAME = "Strike";
/*    */   public static final String DESCRIPTION = "Deal !D! damage.";
/*    */   public static final String IMG_PATH = "cards/strike.png";
/* 19 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 20 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.BASIC;
/* 21 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int POWER = 6;
/*    */   private static final int UPGRADE_BONUS = 3;
/*    */   
/*    */   public Strike_Glutton()
/*    */   {
/* 29 */     super("Strike_Glutton", "Strike", "cards/strike.png", 1, "Deal !D! damage.", TYPE, RARITY, TARGET);
/*    */     
/* 31 */     this.baseDamage = 6;
/* 32 */     this.tags.add(BaseModCardTags.BASIC_STRIKE);
/* 33 */     this.tags.add(AbstractCard.CardTags.STRIKE);
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 38 */     com.megacrit.cardcrawl.dungeons.AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(m, new com.megacrit.cardcrawl.cards.DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.SLASH_DIAGONAL));
/*    */   }
/*    */   
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 44 */     return new Strike_Glutton();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 49 */     if (!this.upgraded)
/*    */     {
/* 51 */       upgradeName();
/* 52 */       upgradeDamage(3);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Strike_Glutton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */