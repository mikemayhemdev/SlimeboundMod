/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Scab extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Scab";
/*    */   public static final String NAME = "Scab";
/*    */   public static final String DESCRIPTION = "Heal !M! HP. NL Shuffle a Hunger_Pang into your discard pile.";
/*    */   public static final String IMG_PATH = "cards/scab.png";
/* 17 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 18 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 19 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 5;
/*    */   private static final int UPGRADE_MAGIC_BONUS = 3;
/*    */   
/*    */   public Scab()
/*    */   {
/* 27 */     super("Scab", "Scab", "cards/scab.png", 1, "Heal !M! HP. NL Shuffle a Hunger_Pang into your discard pile.", TYPE, RARITY, TARGET);
/*    */     
/* 29 */     this.baseMagicNumber = 5;
/* 30 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 35 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.HealAction(p, p, this.magicNumber));
/* 36 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.MakeTempCardInDiscardAction(new HungerPang(), 1));
/*    */   }
/*    */   
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 42 */     return new Scab();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 47 */     if (!this.upgraded)
/*    */     {
/* 49 */       upgradeName();
/* 50 */       upgradeMagicNumber(3);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Scab.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */