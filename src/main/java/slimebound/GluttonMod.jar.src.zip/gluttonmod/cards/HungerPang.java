/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import basemod.abstracts.CustomCard;
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.DrawCardAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardColor;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import com.megacrit.cardcrawl.powers.AbstractPower;
/*    */ import com.megacrit.cardcrawl.relics.AbstractRelic;
/*    */ import gluttonmod.GluttonMod;
/*    */ 
/*    */ public class HungerPang extends CustomCard
/*    */ {
/*    */   public static final String ID = "HungerPang";
/*    */   public static final String NAME = "Hunger Pang";
/*    */   public static final String DESCRIPTION = "Unplayable. NL When drawn, lose 2 HP and draw another card.";
/*    */   public static final String UPGRADE_DESCRIPTION = "Unplayable. NL When drawn, lose 4 HP and draw another two cards.";
/*    */   public static final String IMG_PATH = "cards/hungerpang.png";
/* 24 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.STATUS;
/* 25 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 26 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.NONE;
/*    */   
/* 28 */   private int actualHungerDamage = 2;
/* 29 */   private int cardDrawAmount = 1;
/* 30 */   private static int UPG_DAMAGE = 4;
/* 31 */   private static int UPG_DRAW = 2;
/*    */   
/*    */   public HungerPang() {
/* 34 */     super("HungerPang", "Hunger Pang", GluttonMod.getResourcePath("cards/hungerpang.png"), -2, "Unplayable. NL When drawn, lose 2 HP and draw another card.", TYPE, AbstractCard.CardColor.COLORLESS, RARITY, TARGET);
/*    */   }
/*    */   
/*    */ 
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 40 */     if (p.hasRelic("Medical Kit")) {
/* 41 */       useMedicalKit(p);
/*    */     } else {
/* 43 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.utility.UseCardAction(this));
/*    */     }
/*    */   }
/*    */   
/*    */   public void triggerWhenDrawn()
/*    */   {
/* 49 */     if ((AbstractDungeon.player.hasPower("Evolve")) && (!AbstractDungeon.player.hasPower("No Draw")))
/*    */     {
/* 51 */       AbstractDungeon.player.getPower("Evolve").flash();
/* 52 */       AbstractDungeon.actionManager.addToBottom(new DrawCardAction(AbstractDungeon.player, 
/* 53 */         AbstractDungeon.player.getPower("Evolve").amount));
/*    */     }
/* 55 */     AbstractRelic lollipop = AbstractDungeon.player.getRelic("Lollipop");
/* 56 */     int damage = this.actualHungerDamage;
/* 57 */     if (lollipop != null) {
/* 58 */       lollipop.flash();
/* 59 */       damage--;
/*    */     }
/* 61 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.LoseHPAction(AbstractDungeon.player, AbstractDungeon.player, damage, com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.FIRE));
/*    */     
/*    */ 
/* 64 */     AbstractDungeon.actionManager.addToBottom(new DrawCardAction(AbstractDungeon.player, this.cardDrawAmount));
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 69 */     return new HungerPang();
/*    */   }
/*    */   
/*    */   public void upgrade() {
/* 73 */     if (!this.upgraded)
/*    */     {
/* 75 */       upgradeName();
/* 76 */       this.actualHungerDamage = UPG_DAMAGE;
/* 77 */       this.cardDrawAmount = UPG_DRAW;
/* 78 */       this.rawDescription = "Unplayable. NL When drawn, lose 4 HP and draw another two cards.";
/* 79 */       initializeDescription();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\HungerPang.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */