/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.cards.CardGroup;
/*    */ import com.megacrit.cardcrawl.cards.DamageInfo;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Reminisce extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Reminisce";
/*    */   public static final String NAME = "Reminisce";
/*    */   public static final String DESCRIPTION = "Deal !D! damage for each card in your Exhaust pile.";
/* 18 */   public static final String[] EXTENDED_DESCRIPTION = { " NL ", " 1 card exhausted.", " cards exhausted." };
/*    */   
/*    */   public static final String IMG_PATH = "cards/reminisce.png";
/* 21 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 22 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.RARE;
/* 23 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ENEMY;
/*    */   
/*    */   private static final int COST = 2;
/*    */   private static final int POWER = 4;
/*    */   private static final int UPGRADE_POWER = 1;
/*    */   
/*    */   public Reminisce()
/*    */   {
/* 31 */     super("Reminisce", "Reminisce", "cards/reminisce.png", 2, "Deal !D! damage for each card in your Exhaust pile.", TYPE, RARITY, TARGET);
/*    */     
/* 33 */     this.baseDamage = 4;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 38 */     int timesHit = p.exhaustPile.size();
/* 39 */     for (int i = 0; i < timesHit - 1; i++) {
/* 40 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.PummelDamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn)));
/*    */     }
/*    */     
/* 43 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAction(m, new DamageInfo(p, this.damage, this.damageTypeForTurn), com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.BLUNT_HEAVY));
/*    */     
/*    */ 
/* 46 */     this.rawDescription = "Deal !D! damage for each card in your Exhaust pile.";
/* 47 */     initializeDescription();
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 52 */     return new Reminisce();
/*    */   }
/*    */   
/*    */   public void applyPowers()
/*    */   {
/* 57 */     int timesHit = AbstractDungeon.player.exhaustPile.size();
/* 58 */     super.applyPowers();
/* 59 */     if (timesHit == 1) {
/* 60 */       this.rawDescription = ("Deal !D! damage for each card in your Exhaust pile." + EXTENDED_DESCRIPTION[0] + EXTENDED_DESCRIPTION[1]);
/*    */     }
/*    */     else {
/* 63 */       this.rawDescription = ("Deal !D! damage for each card in your Exhaust pile." + EXTENDED_DESCRIPTION[0] + timesHit + EXTENDED_DESCRIPTION[2]);
/*    */     }
/*    */     
/* 66 */     initializeDescription();
/*    */   }
/*    */   
/*    */   public void calculateCardDamage(AbstractMonster mo)
/*    */   {
/* 71 */     super.calculateCardDamage(mo);
/* 72 */     int timesHit = AbstractDungeon.player.exhaustPile.size();
/* 73 */     if (timesHit == 1) {
/* 74 */       this.rawDescription = ("Deal !D! damage for each card in your Exhaust pile." + EXTENDED_DESCRIPTION[0] + EXTENDED_DESCRIPTION[1]);
/*    */     }
/*    */     else {
/* 77 */       this.rawDescription = ("Deal !D! damage for each card in your Exhaust pile." + EXTENDED_DESCRIPTION[0] + timesHit + EXTENDED_DESCRIPTION[2]);
/*    */     }
/*    */     
/* 80 */     initializeDescription();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 85 */     if (!this.upgraded)
/*    */     {
/* 87 */       upgradeName();
/* 88 */       upgradeDamage(1);
/* 89 */       initializeDescription();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Reminisce.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */