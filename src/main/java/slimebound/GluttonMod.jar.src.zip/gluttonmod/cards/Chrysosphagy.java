/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.common.HealAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Chrysosphagy extends AbstractGluttonCard
/*    */ {
/*    */   private static final int PRICE = 20;
/*    */   public static final String ID = "Chrysosphagy";
/*    */   public static final String NAME = "Chrysosphagy";
/*    */   public static final String DESCRIPTION = "Pay 20 Gold. NL Heal !M! HP.";
/*    */   public static final String CANT_PLAY = "I can't afford this card.";
/*    */   public static final String IMG_PATH = "cards/chrysosphagy.png";
/* 20 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 21 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 22 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.SELF;
/*    */   
/*    */   private static final int COST = 2;
/*    */   private static final int UPGRADE_COST = 1;
/*    */   private static final int MAGIC = 20;
/*    */   
/*    */   public Chrysosphagy()
/*    */   {
/* 30 */     super("Chrysosphagy", "Chrysosphagy", "cards/chrysosphagy.png", 2, "Pay 20 Gold. NL Heal !M! HP.", TYPE, RARITY, TARGET);
/*    */     
/* 32 */     this.baseMagicNumber = 20;
/* 33 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m) {
/* 37 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.unique.SpendGoldCombatAction(20));
/* 38 */     AbstractDungeon.actionManager.addToBottom(new HealAction(p, p, this.magicNumber));
/*    */   }
/*    */   
/*    */   public boolean canUse(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 43 */     boolean canUse = super.canUse(p, m);
/* 44 */     if (!canUse) {
/* 45 */       return false;
/*    */     }
/* 47 */     if (p.gold < 20) {
/* 48 */       this.cantUseMessage = "I can't afford this card.";
/* 49 */       return false;
/*    */     }
/* 51 */     return true;
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 56 */     return new Chrysosphagy();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 61 */     if (!this.upgraded)
/*    */     {
/* 63 */       upgradeName();
/* 64 */       upgradeBaseCost(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Chrysosphagy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */