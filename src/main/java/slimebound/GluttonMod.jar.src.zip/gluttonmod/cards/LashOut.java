/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.animations.VFXAction;
/*    */ import com.megacrit.cardcrawl.actions.common.ExhaustAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import com.megacrit.cardcrawl.vfx.combat.CleaveEffect;
/*    */ 
/*    */ public class LashOut extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "LashOut";
/*    */   public static final String NAME = "Lash Out";
/*    */   public static final String DESCRIPTION = "Exhaust a random card. NL Deal !D! damage to ALL enemies.";
/*    */   public static final String UPGRADE_DESCRIPTION = "Exhaust a card. NL Deal !D! damage to ALL enemies.";
/*    */   public static final String IMG_PATH = "cards/lashout.png";
/* 21 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 22 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 23 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ALL_ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int POWER = 12;
/*    */   
/*    */   public LashOut()
/*    */   {
/* 30 */     super("LashOut", "Lash Out", "cards/lashout.png", 1, "Exhaust a random card. NL Deal !D! damage to ALL enemies.", TYPE, RARITY, TARGET);
/*    */     
/* 32 */     this.baseDamage = 12;
/* 33 */     this.isMultiDamage = true;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 38 */     if (this.upgraded) {
/* 39 */       AbstractDungeon.actionManager.addToBottom(new ExhaustAction(p, p, 1, false));
/*    */     } else {
/* 41 */       AbstractDungeon.actionManager.addToBottom(new ExhaustAction(p, p, 1, true));
/*    */     }
/*    */     
/* 44 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.utility.SFXAction("ATTACK_HEAVY"));
/*    */     
/* 46 */     AbstractDungeon.actionManager.addToBottom(new VFXAction(p, new CleaveEffect(), 0.1F));
/*    */     
/* 48 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAllEnemiesAction(p, this.multiDamage, this.damageTypeForTurn, com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.NONE));
/*    */   }
/*    */   
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 54 */     return new LashOut();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 59 */     if (!this.upgraded)
/*    */     {
/* 61 */       upgradeName();
/* 62 */       this.rawDescription = "Exhaust a card. NL Deal !D! damage to ALL enemies.";
/* 63 */       initializeDescription();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\LashOut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */