/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect;
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.actions.animations.VFXAction;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ import com.megacrit.cardcrawl.monsters.MonsterGroup;
/*    */ import com.megacrit.cardcrawl.rooms.AbstractRoom;
/*    */ 
/*    */ public class Borborygmi extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Borborygmi";
/*    */   public static final String NAME = "Borborygmi";
/*    */   public static final String DESCRIPTION = "Deal !D! damage and apply !M! Weak to ALL enemies.";
/*    */   public static final String IMG_PATH = "cards/borborygmi.png";
/* 21 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.ATTACK;
/* 22 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.COMMON;
/* 23 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.ALL_ENEMY;
/*    */   
/*    */   private static final int COST = 1;
/*    */   private static final int MAGIC = 1;
/*    */   private static final int POWER = 4;
/*    */   private static final int UPGRADE_BONUS = 1;
/*    */   
/*    */   public Borborygmi()
/*    */   {
/* 32 */     super("Borborygmi", "Borborygmi", "cards/borborygmi.png", 1, "Deal !D! damage and apply !M! Weak to ALL enemies.", TYPE, RARITY, TARGET);
/*    */     
/* 34 */     this.baseMagicNumber = 1;
/* 35 */     this.baseDamage = 4;
/* 36 */     this.magicNumber = this.baseMagicNumber;
/* 37 */     this.isMultiDamage = true;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 42 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.utility.SFXAction("THUNDERCLAP", 0.05F));
/* 43 */     for (AbstractMonster mo : AbstractDungeon.getCurrRoom().monsters.monsters) {
/* 44 */       if (!mo.isDeadOrEscaped()) {
/* 45 */         AbstractDungeon.actionManager.addToBottom(new VFXAction(new com.megacrit.cardcrawl.vfx.combat.LightningEffect(mo.drawX, mo.drawY), 0.05F));
/*    */       }
/*    */     }
/* 48 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DamageAllEnemiesAction(p, this.multiDamage, this.damageTypeForTurn, AbstractGameAction.AttackEffect.NONE));
/*    */     
/* 50 */     for (AbstractMonster mo : AbstractDungeon.getCurrRoom().monsters.monsters) {
/* 51 */       AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.ApplyPowerAction(mo, p, new com.megacrit.cardcrawl.powers.WeakPower(mo, this.magicNumber, false), this.magicNumber, true, AbstractGameAction.AttackEffect.NONE));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 59 */     return new Borborygmi();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 64 */     if (!this.upgraded)
/*    */     {
/* 66 */       upgradeName();
/* 67 */       upgradeMagicNumber(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Borborygmi.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */