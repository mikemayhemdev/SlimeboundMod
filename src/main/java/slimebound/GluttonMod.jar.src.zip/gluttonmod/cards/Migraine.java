/*    */ package gluttonmod.cards;
/*    */ 
/*    */ import com.megacrit.cardcrawl.actions.GameActionManager;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardRarity;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardTarget;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard.CardType;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
/*    */ import com.megacrit.cardcrawl.monsters.AbstractMonster;
/*    */ 
/*    */ public class Migraine extends AbstractGluttonCard
/*    */ {
/*    */   public static final String ID = "Migraine";
/*    */   public static final String NAME = "Migraine";
/*    */   public static final String DESCRIPTION = "Unplayable. NL When drawn, lose 1 HP and draw !M! cards.";
/*    */   public static final String CANT_PLAY = "I can't play this card.";
/*    */   public static final String IMG_PATH = "cards/migraine.png";
/* 18 */   private static final AbstractCard.CardType TYPE = AbstractCard.CardType.SKILL;
/* 19 */   private static final AbstractCard.CardRarity RARITY = AbstractCard.CardRarity.UNCOMMON;
/* 20 */   private static final AbstractCard.CardTarget TARGET = AbstractCard.CardTarget.NONE;
/*    */   
/*    */   private static final int COST = -2;
/*    */   private static final int PAIN = 1;
/*    */   private static final int MAGIC = 2;
/*    */   private static final int UPGRADE_MAGIC_BONUS = 1;
/*    */   
/*    */   public Migraine()
/*    */   {
/* 29 */     super("Migraine", "Migraine", "cards/migraine.png", -2, "Unplayable. NL When drawn, lose 1 HP and draw !M! cards.", TYPE, RARITY, TARGET);
/* 30 */     this.baseMagicNumber = 2;
/* 31 */     this.magicNumber = this.baseMagicNumber;
/*    */   }
/*    */   
/*    */   public void use(AbstractPlayer p, AbstractMonster m) {}
/*    */   
/*    */   public boolean canUse(AbstractPlayer p, AbstractMonster m)
/*    */   {
/* 38 */     this.cantUseMessage = "I can't play this card.";
/* 39 */     return false;
/*    */   }
/*    */   
/*    */   public void triggerWhenDrawn()
/*    */   {
/* 44 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.LoseHPAction(AbstractDungeon.player, AbstractDungeon.player, 1, com.megacrit.cardcrawl.actions.AbstractGameAction.AttackEffect.FIRE));
/*    */     
/*    */ 
/*    */ 
/* 48 */     AbstractDungeon.actionManager.addToBottom(new com.megacrit.cardcrawl.actions.common.DrawCardAction(AbstractDungeon.player, this.magicNumber));
/*    */   }
/*    */   
/*    */   public com.megacrit.cardcrawl.cards.AbstractCard makeCopy()
/*    */   {
/* 53 */     return new Migraine();
/*    */   }
/*    */   
/*    */   public void upgrade()
/*    */   {
/* 58 */     if (!this.upgraded)
/*    */     {
/* 60 */       upgradeName();
/* 61 */       upgradeMagicNumber(1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\cards\Migraine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */