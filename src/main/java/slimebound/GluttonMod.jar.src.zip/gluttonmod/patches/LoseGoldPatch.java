/*    */ package gluttonmod.patches;
/*    */ 
/*    */ import com.evacipated.cardcrawl.modthespire.lib.SpirePatch;
/*    */ import com.megacrit.cardcrawl.cards.AbstractCard;
/*    */ import com.megacrit.cardcrawl.cards.CardGroup;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import gluttonmod.cards.AbstractGluttonCard;
/*    */ import java.util.Stack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SpirePatch(clz=AbstractPlayer.class, method="loseGold")
/*    */ public class LoseGoldPatch
/*    */ {
/* 16 */   private static Stack<Integer> goldStack = new Stack();
/*    */   
/*    */   public static void Prefix(AbstractPlayer abstractPlayer, int amount) {
/* 19 */     if (amount > abstractPlayer.gold) {
/* 20 */       goldStack.push(Integer.valueOf(abstractPlayer.gold));
/*    */     }
/*    */     else {
/* 23 */       goldStack.push(Integer.valueOf(amount));
/*    */     }
/*    */   }
/*    */   
/*    */   public static void Postfix(AbstractPlayer abstractPlayer, int amount) {
/* 28 */     int realAmount = ((Integer)goldStack.pop()).intValue();
/* 29 */     if (realAmount > 0) {
/* 30 */       applyToCardsInGroup(abstractPlayer.drawPile, realAmount);
/* 31 */       applyToCardsInGroup(abstractPlayer.discardPile, realAmount);
/* 32 */       applyToCardsInGroup(abstractPlayer.hand, realAmount);
/* 33 */       applyToCardsInGroup(abstractPlayer.exhaustPile, realAmount);
/*    */     }
/*    */   }
/*    */   
/*    */   private static void applyToCardsInGroup(CardGroup cardGroup, int amount) {
/* 38 */     for (AbstractCard card : cardGroup.group) {
/* 39 */       if ((card instanceof AbstractGluttonCard)) {
/* 40 */         AbstractGluttonCard goldenCard = (AbstractGluttonCard)card;
/* 41 */         goldenCard.onChangeGold(-1 * amount);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\patches\LoseGoldPatch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */