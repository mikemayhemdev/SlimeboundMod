/*    */ package gluttonmod.patches;
/*    */ 
/*    */ import com.evacipated.cardcrawl.modthespire.lib.SpirePatch;
/*    */ import com.megacrit.cardcrawl.cards.CardGroup;
/*    */ import com.megacrit.cardcrawl.characters.AbstractPlayer;
/*    */ import gluttonmod.cards.AbstractGluttonCard;
/*    */ 
/*    */ @SpirePatch(clz=AbstractPlayer.class, method="gainGold")
/*    */ public class GainGoldPatch
/*    */ {
/*    */   public static void Postfix(AbstractPlayer abstractPlayer, int amount)
/*    */   {
/* 13 */     if (amount > 0) {
/* 14 */       applyToCardsInGroup(abstractPlayer.drawPile, amount);
/* 15 */       applyToCardsInGroup(abstractPlayer.discardPile, amount);
/* 16 */       applyToCardsInGroup(abstractPlayer.hand, amount);
/* 17 */       applyToCardsInGroup(abstractPlayer.exhaustPile, amount);
/*    */     }
/*    */   }
/*    */   
/*    */   private static void applyToCardsInGroup(CardGroup cardGroup, int amount) {
/* 22 */     for (com.megacrit.cardcrawl.cards.AbstractCard card : cardGroup.group) {
/* 23 */       if ((card instanceof AbstractGluttonCard)) {
/* 24 */         AbstractGluttonCard goldenCard = (AbstractGluttonCard)card;
/* 25 */         goldenCard.onChangeGold(amount);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\patches\GainGoldPatch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */