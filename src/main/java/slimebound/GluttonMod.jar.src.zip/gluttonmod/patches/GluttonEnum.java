package gluttonmod.patches;

import com.evacipated.cardcrawl.modthespire.lib.SpireEnum;
import com.megacrit.cardcrawl.characters.AbstractPlayer.PlayerClass;

public class GluttonEnum
{
  @SpireEnum
  public static AbstractPlayer.PlayerClass GLUTTON;
}


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\GluttonMod.jar!\gluttonmod\patches\GluttonEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */