package slimebound.patches;

import com.evacipated.cardcrawl.modthespire.lib.SpireEnum;
import com.megacrit.cardcrawl.helpers.CardLibrary;
import com.megacrit.cardcrawl.helpers.CardLibrary.LibraryType;

public class LibraryTypeEnum
{
  @SpireEnum
  public static LibraryType SLIMEBOUND;
}


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\SlimeboundMod.jar!\slimboundmod\patches\LibraryTypeEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */