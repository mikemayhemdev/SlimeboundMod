package slimebound.patches;

import com.evacipated.cardcrawl.modthespire.lib.SpireEnum;
import com.megacrit.cardcrawl.characters.AbstractPlayer;
import com.megacrit.cardcrawl.characters.AbstractPlayer.PlayerClass;

public class SlimeboundEnum
{
  @SpireEnum
  public static PlayerClass SLIMEBOUND;
}


/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\SlimeboundMod.jar!\slimboundmod\patches\SlimeboundEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */