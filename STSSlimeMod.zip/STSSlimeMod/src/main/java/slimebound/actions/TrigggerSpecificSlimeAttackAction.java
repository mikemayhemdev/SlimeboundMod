/*    */ package slimebound.actions;
/*    */ 
/*    */

import com.megacrit.cardcrawl.actions.AbstractGameAction;
import com.megacrit.cardcrawl.characters.AbstractPlayer;
import com.megacrit.cardcrawl.orbs.AbstractOrb;

/*    */

/*    */
/*    */ public class TrigggerSpecificSlimeAttackAction extends AbstractGameAction {
        public boolean upgradeCard;
        public AbstractOrb o;
    /*    */
    public TrigggerSpecificSlimeAttackAction(AbstractOrb o)
    /*     */ {
        this.o=o;
        /*  25 */
        /*     */
    }

    /*    */
    /*    */
    /*    */
    public void update()
    /*    */ {
        /* 19 */


                o.onStartOfTurn();






            this.isDone = true;  /*    */
        }
        /*    */
    }



/* Location:              C:\Program Files (x86)\Steam\steamapps\common\SlayTheSpire\mods\SlimeboundMod.jar!\slimboundmod\actions\RandomBasicSlimeCardAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */